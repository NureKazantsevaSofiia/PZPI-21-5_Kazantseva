package com.ualogistics.auth_common.service;

import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.JWTClaimsSet;

import java.security.KeyPair;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;
import java.util.Date;


public class JweService {

    private final RSAPublicKey publicKey;
    private final RSAPrivateKey privateKey;

    public JweService(KeyPair keyPair) {
        this.publicKey = (RSAPublicKey) keyPair.getPublic();
        this.privateKey = (RSAPrivateKey) keyPair.getPrivate();
    }

    public String generateEncryptedToken(String email) throws JOSEException {
        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .subject(email)
                .issuer("auth-service")
                .issueTime(new Date())
                .expirationTime(new Date(System.currentTimeMillis() + 3600000))
                .build();

        JWEHeader header = new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM)
                .contentType("JWT")
                .build();

        EncryptedJWT jwt = new EncryptedJWT(header, claimsSet);
        jwt.encrypt(new RSAEncrypter(publicKey));

        return jwt.serialize();
    }

    public String extractSubject(String token) throws ParseException, JOSEException {
        EncryptedJWT jwt = EncryptedJWT.parse(token);
        jwt.decrypt(new RSADecrypter(privateKey));
        return jwt.getJWTClaimsSet().getSubject();
    }

    public RSAPrivateKey getPrivateKey() {
        return privateKey;
    }
}