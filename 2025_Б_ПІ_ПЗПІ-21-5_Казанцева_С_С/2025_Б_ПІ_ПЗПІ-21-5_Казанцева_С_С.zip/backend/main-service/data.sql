INSERT INTO users (first_name, last_name, email, password, role)
VALUES ('Ivan', 'Petrenko', 'ivan.petrenko@army.ua', '$2a$10$tCez1cOA5SK7Y6rpW3AjUuE5l5Nz/7gUN/iPjXa2gFnhPvQCDj36y',
        'SOLDIER'),
       ('Andrii', 'Tkachenko', 'andrii.tkachenko@army.ua',
        '$2a$10$tCez1cOA5SK7Y6rpW3AjUuE5l5Nz/7gUN/iPjXa2gFnhPvQCDj36y', 'SOLDIER'),
       ('Serhii', 'Melnyk', 'serhii.melnyk@army.ua', '$2a$10$tCez1cOA5SK7Y6rpW3AjUuE5l5Nz/7gUN/iPjXa2gFnhPvQCDj36y',
        'SOLDIER');


INSERT INTO units (unit_name, unit_type)
VALUES ('Brigade 1', 'BRIGADE'),
       ('Brigade 2', 'BRIGADE');


INSERT INTO soldiers (user_id, added_by, register_number, is_new_account, personal_number, rank, position, unit_id)
VALUES (2, 'admin@gmail.com', 'REG-001', FALSE, 'PN-101', 'MAJOR', 'BRIGADE_COMMANDER', 2),
       (3, 'admin@gmail.com', 'REG-002', FALSE, 'PN-102', 'MAJOR', 'BRIGADE_COMMANDER', 1),
       (4, 'admin@gmail.com', 'REG-003', FALSE, 'PN-103', 'CAPTAIN', 'REGIMENT_COMMANDER', 1);


INSERT INTO missions (description, start_time, end_time, unit_id)
VALUES ('Rescue operation in Zone A', '2025-04-03 06:00:00', '2025-04-10 18:00:00', 2),
       ('Supply delivery to base Delta', '2025-02-12 09:00:00', '2025-03-24 15:00:00', 2),
       ('Recon operation near Sector 5', '2025-04-01 05:00:00', '2025-04-07 17:00:00', 1);


INSERT INTO logistics_requests (request_status, unit_id, mission_id)
VALUES ('PENDING', 1, 2),
       ('APPROVED', 1, 3),
       ('DELIVERED', 2, 1);


INSERT INTO resources (resource_name, price)
VALUES ('First Aid Kit', 50.00),
       ('Ration Pack', 20.00),
       ('Fuel Canister', 75.00),
       ('Ammunition Box', 100.00);


INSERT INTO request_resource (request_id, resource_id, quantity)
VALUES (1, 2, 30),
       (1, 3, 10),
       (2, 4, 5),
       (3, 1, 15);

