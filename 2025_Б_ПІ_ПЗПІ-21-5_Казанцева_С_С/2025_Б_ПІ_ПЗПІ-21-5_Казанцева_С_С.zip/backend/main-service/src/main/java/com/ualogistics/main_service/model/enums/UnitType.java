package com.ualogistics.main_service.model.enums;

public enum UnitType {

    //    SQUAD,         // Відділення (9-15 осіб)
    PLATOON,       // Взвод (15-45 осіб)
    COMPANY,       // Рота (80-200 осіб)
    BATTALION,     // Батальйон (400-800 осіб)
    //    DIVISION,      // Дивізіон (150-650 осіб, артилерійський підрозділ)
//    REGIMENT,      // Полк (900-1500 осіб)
    BRIGADE,       // Бригада (1000-8000 осіб)
//    DIVISION_LARGE // Дивізія (6000-25000 осіб)

//    PLATOON -> COMPANY -> BATTALION -> BRIGADE
}
