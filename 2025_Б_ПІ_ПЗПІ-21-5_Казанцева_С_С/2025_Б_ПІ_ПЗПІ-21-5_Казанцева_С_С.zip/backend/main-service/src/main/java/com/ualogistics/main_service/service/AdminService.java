package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.AuthException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.UpdateAdminRequest;
import com.ualogistics.main_service.model.response.AdminDTO;
import com.ualogistics.main_service.model.response.SoldierDTO;

import java.util.List;

public interface AdminService {

    AdminDTO getAdmin(String email, Long adminId) throws UserException;

    void updateAdmin(String email, Long adminId, UpdateAdminRequest updatedAdmin) throws UserException;

    void addAdmin(String email, Long adminId, String newAdminEmail)
            throws UserException, SecurityException, AuthException;

    String approveAdmin(String email, Long adminId, Long newAdminId) throws UserException;

    void declineAdmin(String email, Long adminId, Long newAdminId) throws UserException;

    List<AdminDTO> getApprovedAdmins(String email) throws UserException;

    List<AdminDTO> getNotApprovedAdmins(String email) throws UserException;

    List<SoldierDTO> getUsers(String email, Long adminId) throws UserException;
}
