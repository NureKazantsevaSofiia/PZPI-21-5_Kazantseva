package com.ualogistics.main_service.exception;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

public class SoldierException extends Exception {

    private final SoldierExceptionProfile soldierExceptionProfile;

    public SoldierException(SoldierExceptionProfile soldierExceptionProfile) {
        super(soldierExceptionProfile.exceptionMessage);
        this.soldierExceptionProfile = soldierExceptionProfile;
    }

    public String getName() {
        return soldierExceptionProfile.exceptionName;
    }

    public HttpStatus getResponseStatus() {
        return soldierExceptionProfile.responseStatus;
    }

    @AllArgsConstructor
    public enum SoldierExceptionProfile {

        SOLDIER_NOT_FOUND("soldier_not_found",
                "Soldier is not found.", HttpStatus.NOT_FOUND),

        SOLDIER_ACCESS_FORBIDDEN("soldier_access_forbidden",
                "Access forbidden. Email provided does not match " +
                        "the authenticated user's email.", HttpStatus.FORBIDDEN),

        ACCESS_FORBIDDEN("forbidden",
                "Access forbidden.", HttpStatus.FORBIDDEN),

        PERSONAL_NUMBER_NOT_UNIQUE("personal_number_not_unique",
                "Personal number should be unique.", HttpStatus.BAD_REQUEST),

        EMAIL_OCCUPIED("email_occupied",
                "Soldier with such email already exists.", HttpStatus.BAD_REQUEST);

        private final String exceptionName;
        private final String exceptionMessage;
        private final HttpStatus responseStatus;
    }
}
