package com.ualogistics.main_service.util;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

public class EncryptionUtil {

    private static final String AES = "AES";
    private static final String AES_GCM_NO_PADDING = "AES/GCM/NoPadding";

    private static final int GCM_IV_LENGTH = 12;
    private static final int GCM_TAG_LENGTH = 128;

    private final SecretKey secretKey;

    public EncryptionUtil(byte[] keyBytes) {
        this.secretKey = new SecretKeySpec(keyBytes, AES);
    }

    public static byte[] generateKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance(AES);
        keyGen.init(256);
        SecretKey key = keyGen.generateKey();
        return key.getEncoded();
    }

    public String encrypt(String plainText) throws Exception {
        Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);

        byte[] iv = new byte[GCM_IV_LENGTH];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);

        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);

        cipher.init(Cipher.ENCRYPT_MODE, secretKey, spec);

        byte[] encrypted = cipher.doFinal(plainText.getBytes());

        byte[] encryptedIVAndText = new byte[GCM_IV_LENGTH + encrypted.length];
        System.arraycopy(iv, 0, encryptedIVAndText, 0, GCM_IV_LENGTH);
        System.arraycopy(encrypted, 0, encryptedIVAndText, GCM_IV_LENGTH, encrypted.length);

        return Base64.getEncoder().encodeToString(encryptedIVAndText);
    }

    public String decrypt(String cipherText) throws Exception {
        byte[] encryptedIvTextBytes = Base64.getDecoder().decode(cipherText);

        byte[] iv = new byte[GCM_IV_LENGTH];
        System.arraycopy(encryptedIvTextBytes, 0, iv, 0, iv.length);

        int encryptedSize = encryptedIvTextBytes.length - GCM_IV_LENGTH;
        byte[] encryptedBytes = new byte[encryptedSize];
        System.arraycopy(encryptedIvTextBytes, GCM_IV_LENGTH, encryptedBytes, 0, encryptedSize);

        Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, spec);

        byte[] decrypted = cipher.doFinal(encryptedBytes);

        return new String(decrypted);
    }
}
