package com.ualogistics.main_service.exception.handler;

import com.ualogistics.main_service.exception.LogisticRequestException;
import com.ualogistics.main_service.exception.dto.ExceptionResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class LogisticRequestExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = LogisticRequestException.class)
    public ResponseEntity<Object> handleLogisticRequestException(LogisticRequestException exception,
                                                                 WebRequest webRequest) {
        var exceptionBody = new ExceptionResponse(exception.getName(), exception.getMessage());

        return handleExceptionInternal(exception, exceptionBody, new HttpHeaders(),
                exception.getResponseStatus(), webRequest);
    }
}
