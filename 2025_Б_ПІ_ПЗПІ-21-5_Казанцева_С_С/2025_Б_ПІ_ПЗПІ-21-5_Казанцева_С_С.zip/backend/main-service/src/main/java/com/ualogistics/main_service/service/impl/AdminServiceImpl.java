package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.exception.AuthException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.entity.Admin;
import com.ualogistics.main_service.model.enums.Role;
import com.ualogistics.main_service.model.request.UpdateAdminRequest;
import com.ualogistics.main_service.model.response.AdminDTO;
import com.ualogistics.main_service.model.response.SoldierDTO;
import com.ualogistics.main_service.repository.AdminRepository;
import com.ualogistics.main_service.repository.SoldierRepository;
import com.ualogistics.main_service.repository.UserRepository;
import com.ualogistics.main_service.service.AdminService;
import com.ualogistics.main_service.util.AuthUtil;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private AdminRepository adminRepository;
    private SoldierRepository soldierRepository;

    private PasswordEncoder passwordEncoder;
    private AuthUtil authUtil;

    @Override
    public AdminDTO getAdmin(String email, Long adminId) throws UserException {
        return new AdminDTO(authUtil.checkAdminByEmailAndId(email, adminId));
    }

    @Override
    public void updateAdmin(String email, Long adminId, UpdateAdminRequest updatedAdmin) throws UserException {
        var admin = authUtil.checkAdminByEmailAndId(email, adminId);

        if (!admin.isApproved()) {
            throw new UserException(UserException.UserExceptionProfile.SOMETHING_WRONG);
        }

        admin.setFirstName(updatedAdmin.getFirstName());
        admin.setLastName(updatedAdmin.getLastName());
        admin.setPassword(passwordEncoder.encode(updatedAdmin.getPassword()));
        admin.setNewAccount(false);

        adminRepository.save(admin);
    }

    @Override
    public void addAdmin(String email, Long adminId, String newAdminEmail)
            throws UserException, SecurityException, AuthException {
        var admin = authUtil.checkAdminByEmailAndId(email, adminId);

        var user = userRepository.findByEmailIgnoreCase(newAdminEmail).orElse(null);

        if (user != null) {
            throw new AuthException(AuthException.AuthExceptionProfile.EMAIL_OCCUPIED);
        }

        Admin newAdmin = Admin.builder()
                .email(newAdminEmail)
                .role(Role.ADMIN)
                .addedBy(admin.getEmail())
                .dateOfAdding(LocalDateTime.now())
                .approved(false)
                .newAccount(true)
                .build();

        adminRepository.save(newAdmin);
    }

    @Override
    public String approveAdmin(String email, Long adminId, Long newAdminId) throws UserException {
        authUtil.checkAdminByEmailAndChief(email, adminId);

        var newAdmin = adminRepository.findById(newAdminId).orElseThrow(
                () -> new UserException(UserException.UserExceptionProfile.ADMIN_NOT_FOUND));

        if (Role.CHIEF_ADMIN.equals(newAdmin.getRole())) {
            throw new UserException(UserException.UserExceptionProfile.PERMISSION_DENIED);
        }

        var password = RandomStringUtils.random(7, true, true);

        newAdmin.setApproved(true);
        newAdmin.setDateOfApproving(LocalDateTime.now());
        newAdmin.setPassword(passwordEncoder.encode(password));

        adminRepository.save(newAdmin);

        return password;
    }

    @Override
    public void declineAdmin(String email, Long adminId, Long newAdminId) throws UserException {
        authUtil.checkAdminByEmailAndChief(email, adminId);

        var newAdmin = adminRepository.findById(newAdminId).orElseThrow(
                () -> new UserException(UserException.UserExceptionProfile.ADMIN_NOT_FOUND));

        if (Role.CHIEF_ADMIN.equals(newAdmin.getRole())) {
            throw new UserException(UserException.UserExceptionProfile.PERMISSION_DENIED);
        }

        adminRepository.delete(newAdmin);
    }

    @Override
    public List<AdminDTO> getApprovedAdmins(String email) throws UserException {
        var admin = adminRepository.findByEmailIgnoreCase(email).orElseThrow(
                () -> new UserException(UserException.UserExceptionProfile.ADMIN_NOT_FOUND));

        return adminRepository.findAllByApprovedTrueOrderByDateOfApproving().stream()
                .filter(a -> a.getRole().equals(Role.ADMIN) && !a.getEmail().equals(admin.getEmail()))
                .map(AdminDTO::new)
                .toList();
    }

    @Override
    public List<AdminDTO> getNotApprovedAdmins(String email) throws UserException {
        var admin = adminRepository.findByEmailIgnoreCase(email).orElseThrow(
                () -> new UserException(UserException.UserExceptionProfile.ADMIN_NOT_FOUND));

        return adminRepository.findAllByApprovedFalseOrderByDateOfAdding().stream()
                .filter(a -> a.getRole().equals(Role.ADMIN) && !a.getEmail().equals(admin.getEmail()))
                .map(AdminDTO::new)
                .toList();
    }

    @Override
    public List<SoldierDTO> getUsers(String email, Long adminId) throws UserException {
        adminRepository.findByEmailIgnoreCase(email).orElseThrow(
                () -> new UserException(UserException.UserExceptionProfile.ADMIN_NOT_FOUND));

        return soldierRepository.findAll().stream().map(SoldierDTO::new).toList();
    }
}
