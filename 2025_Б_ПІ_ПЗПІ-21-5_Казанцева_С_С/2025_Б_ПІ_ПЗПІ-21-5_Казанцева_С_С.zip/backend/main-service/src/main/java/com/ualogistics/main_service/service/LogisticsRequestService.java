package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.*;
import com.ualogistics.main_service.model.request.LogisticsRequestReq;
import com.ualogistics.main_service.model.response.LogisticsRequestDTO;

import java.util.List;

public interface LogisticsRequestService {

    List<String> getRequestStatuses(String email, Long userId) throws SoldierException;

    LogisticsRequestDTO createLogisticsRequest(String email, Long userId, Long missionId,
                                               LogisticsRequestReq request)
            throws SoldierException, MissionException, ResourceException, LogisticRequestException;

    LogisticsRequestDTO updateStatusLogisticsRequest(String email, Long userId, Long missionId,
                                                     Long logisticsRequestId, String status)
            throws SoldierException, MissionException, LogisticRequestException;

    LogisticsRequestDTO updateLogisticsRequest(String email, Long userId, Long missionId,
                                               Long logisticsRequestId, LogisticsRequestReq request)
            throws SoldierException, MissionException, LogisticRequestException, ResourceException;

    LogisticsRequestDTO getLogisticsRequest(String email, Long userId, Long missionId, Long requestId)
            throws SoldierException, MissionException, LogisticRequestException;

    List<LogisticsRequestDTO> getLogisticsRequestsByMission(String email, Long userId, Long missionId)
            throws SoldierException, MissionException;

    List<LogisticsRequestDTO> getLogisticsRequestsByUnit(String email, Long userId, Long unitId)
            throws SoldierException, UnitException;

    void approveExecutionOfLogisticsRequest(String email, Long userId, Long missionId, Long requestId) throws SoldierException, MissionException, LogisticRequestException, ResourceException;
}
