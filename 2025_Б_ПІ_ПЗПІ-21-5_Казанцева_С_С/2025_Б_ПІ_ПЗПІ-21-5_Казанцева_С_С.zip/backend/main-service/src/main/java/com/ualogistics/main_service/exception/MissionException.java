package com.ualogistics.main_service.exception;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

public class MissionException extends Exception {

    private final MissionExceptionProfile missionExceptionProfile;

    public MissionException(MissionExceptionProfile missionExceptionProfile) {
        super(missionExceptionProfile.exceptionMessage);
        this.missionExceptionProfile = missionExceptionProfile;
    }

    public String getName() {
        return missionExceptionProfile.exceptionName;
    }

    public HttpStatus getResponseStatus() {
        return missionExceptionProfile.responseStatus;
    }

    @AllArgsConstructor
    public enum MissionExceptionProfile {

        MISSION_NOT_FOUND("mission_not_found",
                "Mission is not found.", HttpStatus.NOT_FOUND),

        INVALID_COMPLEXITY("invalid_complexity",
                "Complexity should be in the range of 1-3.", HttpStatus.BAD_REQUEST);

        private final String exceptionName;
        private final String exceptionMessage;
        private final HttpStatus responseStatus;
    }
}
