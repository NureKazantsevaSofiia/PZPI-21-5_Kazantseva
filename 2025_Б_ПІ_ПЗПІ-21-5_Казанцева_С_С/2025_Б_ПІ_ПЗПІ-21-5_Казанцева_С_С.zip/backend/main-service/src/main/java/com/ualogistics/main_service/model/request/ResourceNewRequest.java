package com.ualogistics.main_service.model.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
public class ResourceNewRequest {

    @NotEmpty
    @NotNull
    @Size(min = 3, max = 60)
    private String name;

    private String category;
    
    private BigDecimal price;
}
