package com.ualogistics.main_service.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UnitResourcesRequest {

    List<ResourceQuantity> resources;
}
