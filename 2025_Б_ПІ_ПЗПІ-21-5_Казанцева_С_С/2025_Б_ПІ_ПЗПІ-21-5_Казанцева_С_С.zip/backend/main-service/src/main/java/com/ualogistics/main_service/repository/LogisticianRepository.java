package com.ualogistics.main_service.repository;

import com.ualogistics.main_service.model.entity.Logistician;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogisticianRepository extends JpaRepository<Logistician, Long> {
}
