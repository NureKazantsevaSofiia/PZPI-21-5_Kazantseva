package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.model.request.CriticalSupportRequest;
import com.ualogistics.main_service.model.response.CriticalSupportDTO;
import com.ualogistics.main_service.service.CriticalSupportService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
public class CriticalSupportController {

    private CriticalSupportService criticalSupportService;

    @PostMapping("/api/critical-support")
    public CriticalSupportDTO createCriticalSupport(@Valid @RequestBody CriticalSupportRequest criticalSupport) {
        return criticalSupportService.createCriticalSupport(criticalSupport);
    }
}
