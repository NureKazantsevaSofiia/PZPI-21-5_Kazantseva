package com.ualogistics.main_service.model.enums;

public enum Status {

    PENDING,
    APPROVED,
    DELIVERED,
    DECLINED,
    CANCELLED,
    RECEIVED,
    LOST
}
