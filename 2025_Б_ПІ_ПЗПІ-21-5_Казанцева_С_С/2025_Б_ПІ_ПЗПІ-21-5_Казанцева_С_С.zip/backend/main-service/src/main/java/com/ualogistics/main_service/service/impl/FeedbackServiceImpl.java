package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.exception.FeedbackException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.entity.Feedback;
import com.ualogistics.main_service.model.entity.Soldier;
import com.ualogistics.main_service.model.enums.FeedbackStatus;
import com.ualogistics.main_service.model.enums.FeedbackType;
import com.ualogistics.main_service.model.request.FeedbackRequest;
import com.ualogistics.main_service.model.response.FeedbackDTO;
import com.ualogistics.main_service.repository.FeedbackRepository;
import com.ualogistics.main_service.repository.UnitRepository;
import com.ualogistics.main_service.service.FeedbackService;
import com.ualogistics.main_service.util.AuthUtil;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class FeedbackServiceImpl implements FeedbackService {

    private final FeedbackRepository feedbackRepository;
    private AuthUtil authUtil;
    private UnitRepository unitRepository;

    @Override
    public FeedbackDTO createFeedback(String email, Long userId, FeedbackRequest feedback)
            throws SoldierException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        return new FeedbackDTO(feedbackRepository.save(Feedback.builder()
                .text(feedback.getText())
                .unit(soldier.getUnit())
                .type(FeedbackType.valueOf(feedback.getType()))
                .status(FeedbackStatus.NEW)
                .build()
        ));
    }

    @Override
    public FeedbackDTO updateFeedbackStatus(String email, Long userId, Long feedbackId, String newStatus)
            throws FeedbackException, UserException {
        authUtil.checkAdminByEmailAndId(email, userId);

        Feedback feedback = feedbackRepository.findById(feedbackId).orElseThrow(
                () -> new FeedbackException(FeedbackException.FeedbackExceptionProfile.FEEDBACK_NOT_FOUND)
        );

        feedback.setStatus(FeedbackStatus.valueOf(newStatus));

        return new FeedbackDTO(feedbackRepository.save(feedback));
    }

    @Override
    public FeedbackDTO getFeedback(String email, Long userId, Long feedbackId)
            throws UserException, FeedbackException {
        authUtil.checkAdminByEmailAndId(email, userId);

        Feedback feedback = feedbackRepository.findById(feedbackId).orElseThrow(
                () -> new FeedbackException(FeedbackException.FeedbackExceptionProfile.FEEDBACK_NOT_FOUND)
        );

        return new FeedbackDTO(feedback);
    }

    @Override
    public List<FeedbackDTO> getAllFeedbacks(String email, Long userId) throws UserException {
        authUtil.checkAdminByEmailAndId(email, userId);

        List<Feedback> feedback = feedbackRepository.findAll();

        return feedback.stream().map(FeedbackDTO::new).toList();
    }
}
