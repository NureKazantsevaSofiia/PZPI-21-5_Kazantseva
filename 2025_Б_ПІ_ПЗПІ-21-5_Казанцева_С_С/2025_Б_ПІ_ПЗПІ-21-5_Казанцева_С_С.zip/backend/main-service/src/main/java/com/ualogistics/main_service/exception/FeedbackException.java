package com.ualogistics.main_service.exception;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

public class FeedbackException extends Exception {

    private final FeedbackExceptionProfile feedbackExceptionProfile;

    public FeedbackException(FeedbackExceptionProfile feedbackExceptionProfile) {
        super(feedbackExceptionProfile.exceptionMessage);
        this.feedbackExceptionProfile = feedbackExceptionProfile;
    }

    public String getName() {
        return feedbackExceptionProfile.exceptionName;
    }

    public HttpStatus getResponseStatus() {
        return feedbackExceptionProfile.responseStatus;
    }

    @AllArgsConstructor
    public enum FeedbackExceptionProfile {

        FEEDBACK_NOT_FOUND("feedback_not_found",
                "Feedback is not found.", HttpStatus.NOT_FOUND);

        private final String exceptionName;
        private final String exceptionMessage;
        private final HttpStatus responseStatus;
    }
}
