package com.ualogistics.main_service.repository;

import com.ualogistics.main_service.model.entity.CriticalSupport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CriticalSupportRepository extends JpaRepository<CriticalSupport, Long> {
}
