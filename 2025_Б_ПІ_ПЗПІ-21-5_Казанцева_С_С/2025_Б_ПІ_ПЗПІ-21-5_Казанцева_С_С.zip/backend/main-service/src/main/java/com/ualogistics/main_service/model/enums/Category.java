package com.ualogistics.main_service.model.enums;

public enum Category {

    FOOD,
    MEDICINE,
    OTHER
}
