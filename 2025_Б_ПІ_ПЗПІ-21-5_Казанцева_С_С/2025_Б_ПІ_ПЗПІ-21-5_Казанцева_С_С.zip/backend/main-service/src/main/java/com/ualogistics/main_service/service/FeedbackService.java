package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.FeedbackException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.FeedbackRequest;
import com.ualogistics.main_service.model.response.FeedbackDTO;

import java.util.List;

public interface FeedbackService {

    FeedbackDTO createFeedback(String email, Long userId, FeedbackRequest feedback) throws SoldierException;

    //    for Admins

    FeedbackDTO updateFeedbackStatus(String email, Long userId, Long feedbackId, String newStatus)
            throws FeedbackException, UserException;

    FeedbackDTO getFeedback(String email, Long userId, Long feedbackId) throws UserException, FeedbackException;

    List<FeedbackDTO> getAllFeedbacks(String email, Long userId) throws UserException;
}
