package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.Mission;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MissionDTO {

    private Long id;

    private String description;

    private Double complexity;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    public MissionDTO(Mission mission) {
        this.id = mission.getId();
        this.description = mission.getDescription();
        this.complexity = mission.getComplexity();
        this.startTime = mission.getStartTime();
        this.endTime = mission.getEndTime();
    }
}
