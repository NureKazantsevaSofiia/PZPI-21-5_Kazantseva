package com.ualogistics.main_service.repository;

import com.ualogistics.main_service.model.entity.ResourceStock;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ResourceStockRepository extends JpaRepository<ResourceStock, Long> {

    List<ResourceStock> findAllByUnitId(Long unitId);
}
