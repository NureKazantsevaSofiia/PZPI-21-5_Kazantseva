package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UnitException;
import com.ualogistics.main_service.model.request.UnitCreateRequest;
import com.ualogistics.main_service.model.request.UnitUpdateRequest;
import com.ualogistics.main_service.model.response.UnitDTO;
import com.ualogistics.main_service.service.UnitService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class UnitController {

    private UnitService unitService;

    @GetMapping("/api/users/{user-id}/units/types")
    public List<String> getUnitTypes(Authentication auth,
                                     @PathVariable("user-id") Long userId) throws SoldierException {
        return unitService.getUnitTypes(auth.getName(), userId);
    }

    @GetMapping("/api/users/{user-id}/unit")
    public UnitDTO getUnitByUser(Authentication auth,
                                 @PathVariable("user-id") Long userId) throws SoldierException, UnitException {
        return unitService.getUnitByUser(auth.getName(), userId);
    }

    @GetMapping("/api/users/{user-id}/units/{unit-id}")
    public UnitDTO getUnit(Authentication auth,
                           @PathVariable("user-id") Long userId,
                           @PathVariable("unit-id") Long unitId) throws SoldierException, UnitException {
        return unitService.getUnit(auth.getName(), userId, unitId);
    }

    @PostMapping("/api/users/{user-id}/units")
    public UnitDTO createUnit(Authentication auth,
                              @PathVariable("user-id") Long userId,
                              @Valid @RequestBody UnitCreateRequest unit)
            throws SoldierException, UnitException {
        return unitService.createUnit(auth.getName(), userId, unit);
    }

    @PatchMapping("/api/users/{user-id}/units/{unit-id}")
    public UnitDTO updateUnit(Authentication auth,
                              @PathVariable("user-id") Long userId,
                              @PathVariable("unit-id") Long unitId,
                              @Valid @RequestBody UnitUpdateRequest updatedUnit)
            throws SoldierException, UnitException {
        return unitService.updateUnit(auth.getName(), userId, unitId, updatedUnit);
    }
}
