package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.Unit;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UnitDTO {

    private Long id;

    private String name;

    private String type;

    private String parentUnit;

    private Integer soldierAmount;

    private List<SoldierDTO> commanders;

    private List<MissionDTO> missions;

    public UnitDTO(Unit unit) {
        this.id = unit.getId();
        this.name = unit.getName();
        this.type = unit.getType().name();
        this.parentUnit = unit.getParentUnit() == null ? null : unit.getParentUnit().getName();
        this.soldierAmount = unit.getSoldierAmount();
        this.commanders = new ArrayList<>();
        this.missions = new ArrayList<>();

        unit.getSoldiers().forEach(soldier ->
                this.commanders.add(new SoldierDTO(soldier)));

        unit.getMissions().forEach(mission ->
                missions.add(new MissionDTO(mission)));
    }
}
