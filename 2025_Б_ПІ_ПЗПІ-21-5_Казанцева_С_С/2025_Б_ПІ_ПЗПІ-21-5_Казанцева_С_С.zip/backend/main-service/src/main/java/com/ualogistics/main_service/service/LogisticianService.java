package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.ResourceException;
import com.ualogistics.main_service.exception.UnitException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.LogisticianCreateRequest;
import com.ualogistics.main_service.model.request.UnitResourcesRequest;

public interface LogisticianService {

    void createNewLogistician(String email, Long adminId, LogisticianCreateRequest newLogistician) throws UserException;

    void setUpResourcesForUnit(String email, Long logId, Long unitId, UnitResourcesRequest resources) throws UserException, ResourceException, UnitException;
}
