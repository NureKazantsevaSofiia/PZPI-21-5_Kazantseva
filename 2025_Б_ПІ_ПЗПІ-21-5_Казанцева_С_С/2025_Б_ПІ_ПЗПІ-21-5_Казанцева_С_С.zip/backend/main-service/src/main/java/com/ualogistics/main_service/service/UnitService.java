package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UnitException;
import com.ualogistics.main_service.model.request.UnitCreateRequest;
import com.ualogistics.main_service.model.request.UnitUpdateRequest;
import com.ualogistics.main_service.model.response.UnitDTO;

import java.util.List;

public interface UnitService {

    List<String> getUnitTypes(String email, Long userId) throws SoldierException;

    UnitDTO getUnit(String email, Long userId, Long unitId) throws SoldierException, UnitException;

    UnitDTO getUnitByUser(String email, Long userId) throws SoldierException;

    UnitDTO createUnit(String email, Long userId, UnitCreateRequest unit) throws SoldierException, UnitException;

    UnitDTO updateUnit(String email, Long userId, Long unitId, UnitUpdateRequest updatedUnit) throws SoldierException, UnitException;
}
