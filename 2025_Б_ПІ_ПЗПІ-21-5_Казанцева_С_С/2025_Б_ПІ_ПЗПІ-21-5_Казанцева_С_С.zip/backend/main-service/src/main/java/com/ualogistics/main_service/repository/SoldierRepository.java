package com.ualogistics.main_service.repository;

import com.ualogistics.main_service.model.entity.Soldier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SoldierRepository extends JpaRepository<Soldier, Long> {

    boolean existsByPersonalNumber(String personalNumber);

    boolean existsByEmailIgnoreCase(String email);
}
