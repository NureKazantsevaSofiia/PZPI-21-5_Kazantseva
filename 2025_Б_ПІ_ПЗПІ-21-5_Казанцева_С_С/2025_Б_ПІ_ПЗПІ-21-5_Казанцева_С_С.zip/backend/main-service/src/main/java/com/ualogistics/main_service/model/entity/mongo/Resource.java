package com.ualogistics.main_service.model.entity.mongo;

import jakarta.persistence.Id;
import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

import java.math.BigDecimal;

@Document
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Resource {

    @Id
    private String id;

    private String category;

    private String name;

    @Field(targetType = FieldType.DECIMAL128)
    private BigDecimal price;
}
