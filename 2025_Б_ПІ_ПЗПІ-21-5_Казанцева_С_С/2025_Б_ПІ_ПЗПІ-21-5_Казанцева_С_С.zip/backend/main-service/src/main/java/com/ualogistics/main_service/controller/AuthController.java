package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.model.response.LoginResponse;
import com.ualogistics.main_service.service.AuthService;
import com.ualogistics.main_service.util.EncryptionUtil;
import com.ualogistics.main_service.util.swagger.AuthAPI;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@AllArgsConstructor
public class AuthController implements AuthAPI {

    private AuthService authService;
    private EncryptionUtil encryptionUtil;

    @PostMapping("/api/login")
    public LoginResponse login(Authentication authentication) throws Exception {
        var test = encryptionUtil.encrypt("My test");
        Logger.getLogger(AuthController.class.getName()).log(Level.INFO,
                "\n\n\n" + test
                        + "\n" + encryptionUtil.decrypt(test) + "\n\n\n");
        return authService.login(authentication);
    }
}