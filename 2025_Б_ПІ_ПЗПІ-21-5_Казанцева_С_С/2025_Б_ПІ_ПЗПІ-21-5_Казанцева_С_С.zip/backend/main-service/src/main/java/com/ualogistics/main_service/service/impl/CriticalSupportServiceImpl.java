package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.model.entity.CriticalSupport;
import com.ualogistics.main_service.model.request.CriticalSupportRequest;
import com.ualogistics.main_service.model.response.CriticalSupportDTO;
import com.ualogistics.main_service.repository.CriticalSupportRepository;
import com.ualogistics.main_service.service.CriticalSupportService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class CriticalSupportServiceImpl implements CriticalSupportService {

    private CriticalSupportRepository criticalSupportRepository;

    @Override
    public CriticalSupportDTO createCriticalSupport(CriticalSupportRequest criticalSupport) {
        return new CriticalSupportDTO(criticalSupportRepository.save(
                CriticalSupport.builder()
                        .userId(criticalSupport.getUserId())
                        .battleGroupName(criticalSupport.getBattleGroupName())
                        .position(criticalSupport.getPosition())
                        .description(criticalSupport.getDescription())
                        .build()
        ));
    }
}
