package com.ualogistics.main_service.model.enums;

public enum FeedbackStatus {

    NEW,
    UNDER_REVIEW,
    IN_PROGRESS,
    COMPLETED,
    REJECTED
}
