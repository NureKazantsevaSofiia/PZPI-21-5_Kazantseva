package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.RequestResource;
import com.ualogistics.main_service.model.entity.mongo.Resource;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RequestResourceDTO {

    private String resourceId;

    private String name;

    private String category;

    private BigDecimal price;

    private int quantity;

    public RequestResourceDTO(RequestResource request, Resource resource) {
        this.resourceId = resource.getId();
        this.name = resource.getName();
        this.price = resource.getPrice();
        this.category = resource.getCategory();
        this.quantity = request.getQuantity();
    }

    public RequestResourceDTO(Resource resource, int quantity) {
        this.resourceId = resource.getId();
        this.name = resource.getName();
        this.category = resource.getCategory();
        this.price = resource.getPrice().multiply(BigDecimal.valueOf(quantity));
        this.quantity = quantity;
    }
}
