package com.ualogistics.main_service.model.entity;

import com.ualogistics.main_service.model.enums.Role;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@SuperBuilder
@Getter
@Setter
@AllArgsConstructor
@Table(name = "logisticians")
public class Logistician extends User {

    @Column(name = "added_by")
    private String addedBy;

    public Logistician() {
        this.setRole(Role.LOGISTICIAN);
    }
}