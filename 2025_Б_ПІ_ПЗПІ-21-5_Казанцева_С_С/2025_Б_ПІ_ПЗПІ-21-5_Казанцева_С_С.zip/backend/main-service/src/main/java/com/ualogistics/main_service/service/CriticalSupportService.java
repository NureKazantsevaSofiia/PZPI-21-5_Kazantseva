package com.ualogistics.main_service.service;

import com.ualogistics.main_service.model.request.CriticalSupportRequest;
import com.ualogistics.main_service.model.response.CriticalSupportDTO;

public interface CriticalSupportService {

    CriticalSupportDTO createCriticalSupport(CriticalSupportRequest criticalSupport);
}
