package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.CriticalSupport;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CriticalSupportDTO {

    private Long id;

    private Long userId;

    private String battleGroupName;

    private String position;

    private String description;

    public CriticalSupportDTO(CriticalSupport criticalSupport) {
        this.id = criticalSupport.getId();
        this.userId = criticalSupport.getUserId();
        this.battleGroupName = criticalSupport.getBattleGroupName();
        this.position = criticalSupport.getPosition();
        this.description = criticalSupport.getDescription();
    }
}
