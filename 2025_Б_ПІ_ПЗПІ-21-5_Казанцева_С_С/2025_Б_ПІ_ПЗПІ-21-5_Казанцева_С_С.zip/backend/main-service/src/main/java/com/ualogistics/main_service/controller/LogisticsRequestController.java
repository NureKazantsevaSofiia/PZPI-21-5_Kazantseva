package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.exception.*;
import com.ualogistics.main_service.model.request.LogisticsRequestReq;
import com.ualogistics.main_service.model.response.LogisticsRequestDTO;
import com.ualogistics.main_service.service.LogisticsRequestService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class LogisticsRequestController {

    private LogisticsRequestService logisticsRequestService;

    @GetMapping("/api/users/{user-id}/request-statuses")
    public List<String> getRequestStatuses(Authentication auth,
                                           @PathVariable("user-id") Long userId)
            throws SoldierException {
        return logisticsRequestService.getRequestStatuses(auth.getName(), userId);
    }

    @PostMapping("/api/users/{user-id}/missions/{mission-id}/requests")
    public LogisticsRequestDTO createLogisticsRequest(Authentication auth,
                                                      @PathVariable("user-id") Long userId,
                                                      @PathVariable("mission-id") Long missionId,
                                                      @Valid @RequestBody LogisticsRequestReq request)
            throws MissionException, SoldierException, ResourceException, LogisticRequestException {
        return logisticsRequestService.createLogisticsRequest(auth.getName(), userId, missionId, request);
    }

    @PatchMapping("/api/users/{user-id}/missions/{mission-id}/requests/{request-id}/status/{status}")
    public LogisticsRequestDTO updateStatusLogisticsRequest(Authentication auth,
                                                            @PathVariable("user-id") Long userId,
                                                            @PathVariable("mission-id") Long missionId,
                                                            @PathVariable("request-id") Long requestId,
                                                            @PathVariable("status") String status)
            throws SoldierException, MissionException, LogisticRequestException {
        return logisticsRequestService.updateStatusLogisticsRequest(auth.getName(), userId, missionId,
                requestId, status);
    }

    @PatchMapping("/api/users/{user-id}/missions/{mission-id}/requests/{request-id}")
    public LogisticsRequestDTO updateLogisticsRequest(Authentication auth,
                                                      @PathVariable("user-id") Long userId,
                                                      @PathVariable("mission-id") Long missionId,
                                                      @PathVariable("request-id") Long requestId,
                                                      @Valid @RequestBody LogisticsRequestReq request)
            throws MissionException, SoldierException, ResourceException, LogisticRequestException {
        return logisticsRequestService.updateLogisticsRequest(auth.getName(), userId, missionId,
                requestId, request);
    }

    @PostMapping("/api/users/{user-id}/missions/{mission-id}/requests/{request-id}/approve")
    public void approveExecutionOfLogisticsRequest(Authentication auth,
                                                   @PathVariable("user-id") Long userId,
                                                   @PathVariable("mission-id") Long missionId,
                                                   @PathVariable("mission-id") Long requestId)
            throws MissionException, SoldierException, ResourceException, LogisticRequestException {
        logisticsRequestService.approveExecutionOfLogisticsRequest(auth.getName(), userId, missionId, requestId);
    }

    @GetMapping("/api/users/{user-id}/missions/{mission-id}/requests/{request-id}")
    public LogisticsRequestDTO getLogisticsRequest(Authentication auth,
                                                   @PathVariable("user-id") Long userId,
                                                   @PathVariable("mission-id") Long missionId,
                                                   @PathVariable("request-id") Long requestId)
            throws MissionException, SoldierException, LogisticRequestException {
        return logisticsRequestService.getLogisticsRequest(auth.getName(), userId, missionId, requestId);
    }

    @GetMapping("/api/users/{user-id}/missions/{mission-id}/requests")
    public List<LogisticsRequestDTO> getLogisticsRequestsByMission(Authentication auth,
                                                                   @PathVariable("user-id") Long userId,
                                                                   @PathVariable("mission-id") Long missionId)
            throws MissionException, SoldierException {
        return logisticsRequestService.getLogisticsRequestsByMission(auth.getName(), userId, missionId);
    }

    @GetMapping("/api/users/{user-id}/units/{unit-id}/requests")
    public List<LogisticsRequestDTO> getLogisticsRequestsByUnit(Authentication auth,
                                                                @PathVariable("user-id") Long userId,
                                                                @PathVariable("unit-id") Long unitId)
            throws SoldierException, UnitException {
        return logisticsRequestService.getLogisticsRequestsByUnit(auth.getName(), userId, unitId);
    }
}
