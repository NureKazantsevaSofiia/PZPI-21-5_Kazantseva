package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.Feedback;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FeedbackDTO {

    private Long id;

    private String text;

    private String unitName;

    private String unitType;

    private String type;

    private String status;

    public FeedbackDTO(Feedback feedback) {
        this.id = feedback.getId();
        this.text = feedback.getText();
        this.unitName = feedback.getUnit().getName();
        this.unitType = feedback.getUnit().getType().name();
        this.type = feedback.getType().name();
        this.status = feedback.getStatus().name();
    }
}
