package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.exception.MissionException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.model.entity.LogisticsRequest;
import com.ualogistics.main_service.model.entity.Mission;
import com.ualogistics.main_service.model.entity.Soldier;
import com.ualogistics.main_service.model.request.MissionRequest;
import com.ualogistics.main_service.model.response.*;
import com.ualogistics.main_service.repository.MissionRepository;
import com.ualogistics.main_service.repository.mongo.ResourceRepository;
import com.ualogistics.main_service.service.MissionService;
import com.ualogistics.main_service.util.AuthUtil;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class MissionServiceImpl implements MissionService {

    private AuthUtil authUtil;
    private MissionRepository missionRepository;
    private ResourceRepository resourceRepository;

    @Override
    public FullMissionDTO getMission(String email, Long userId, Long missionId)
            throws SoldierException, MissionException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        if (!soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        return toFullMissionDTO(mission);
    }

    @Override
    public FullMissionDTO createMission(String email, Long userId, MissionRequest newMission)
            throws SoldierException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

//        add validation

        Mission mission = new Mission();
        mission.setDescription(newMission.getDescription());
        mission.setStartTime(newMission.getStartTime());
        mission.setEndTime(newMission.getEndTime());
        mission.setUnit(soldier.getUnit());

        return toFullMissionDTO(missionRepository.save(mission));
    }

    @Override
    public FullMissionDTO updateMission(String email, Long userId, Long missionId, MissionRequest updatedMission)
            throws SoldierException, MissionException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        if (!soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        mission.setDescription(updatedMission.getDescription());
        mission.setStartTime(updatedMission.getStartTime());
        mission.setEndTime(updatedMission.getEndTime());

        return toFullMissionDTO(missionRepository.save(mission));
    }

    @Override
    public List<MissionDTO> getMissions(String email, Long userId) throws SoldierException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        return missionRepository.findByUnitId(soldier.getUnit().getId()).stream()
                .map(MissionDTO::new).collect(Collectors.toList());
    }

    @Override
    public FullMissionDTO updateMissionComplexity(String email, Long userId, Long missionId, double complexity)
            throws SoldierException, MissionException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        if (!soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        if (complexity < 1 || complexity > 3) {
            throw new MissionException(MissionException.MissionExceptionProfile.INVALID_COMPLEXITY);
        }

        mission.setComplexity(complexity);

        return toFullMissionDTO(missionRepository.save(mission));
    }

    private FullMissionDTO toFullMissionDTO(Mission mission) {
        var requests = new ArrayList<LogisticsRequestDTO>();
        mission.getRequests().forEach(r ->
                requests.add(toLogisticsRequestDTO(r))
        );
        return FullMissionDTO.builder()
                .id(mission.getId())
                .description(mission.getDescription())
                .startTime(mission.getStartTime())
                .endTime(mission.getEndTime())
                .requests(requests)
                .build();
    }

    private LogisticsRequestDTO toLogisticsRequestDTO(LogisticsRequest logisticsRequest) {
        var resources = new ArrayList<RequestResourceDTO>();
        logisticsRequest.getRequestsResources().forEach(res -> {
            if (res.getResourceId() != null) {
                resourceRepository.findById(res.getResourceId())
                        .ifPresent(resource -> resources.add(new RequestResourceDTO(res, resource)));
            }
        });

        return LogisticsRequestDTO.builder()
                .id(logisticsRequest.getId())
                .status(logisticsRequest.getStatus().toString())
                .unit(new ShortUnitDTO(logisticsRequest.getUnit()))
                .missionId(logisticsRequest.getMission().getId())
                .resources(resources)
                .build();
    }

}
