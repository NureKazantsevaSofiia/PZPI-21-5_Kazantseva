package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.RequestResource;
import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RequestResourceShortDTO {

    private String resourceId;

    private int quantity;

    public RequestResourceShortDTO(RequestResource resource) {
        this.resourceId = resource.getResourceId();
        this.quantity = resource.getQuantity();
    }
}
