package com.ualogistics.main_service.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "supports")
public class CriticalSupport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "support_id")
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "battle_group_name")
    private String battleGroupName;

    @Column(name = "position")
    private String position;

    @Column(name = "description")
    private String description;
}
