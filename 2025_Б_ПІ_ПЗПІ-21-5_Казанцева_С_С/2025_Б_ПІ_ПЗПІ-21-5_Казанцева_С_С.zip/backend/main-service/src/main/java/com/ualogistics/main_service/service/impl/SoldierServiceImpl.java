package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.entity.Soldier;
import com.ualogistics.main_service.model.enums.Position;
import com.ualogistics.main_service.model.request.SoldierCreateRequest;
import com.ualogistics.main_service.model.request.SoldierRequest;
import com.ualogistics.main_service.model.response.SoldierDTO;
import com.ualogistics.main_service.repository.SoldierRepository;
import com.ualogistics.main_service.service.SoldierService;
import com.ualogistics.main_service.util.AuthUtil;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
@AllArgsConstructor
public class SoldierServiceImpl implements SoldierService {

    private AuthUtil authUtil;
    private SoldierRepository soldierRepository;
    private PasswordEncoder passwordEncoder;

    @Override
    public List<String> getPositions(String email, Long userId) throws SoldierException {
        authUtil.findSoldierByEmailAndId(email, userId);

        return List.of(Arrays.stream(Position.values()).map(Position::name).toArray(String[]::new));
    }

    @Override
    public SoldierDTO getSoldier(String email, Long userId) throws SoldierException {
        return new SoldierDTO(authUtil.findSoldierByEmailAndId(email, userId));
    }

    @Override
    public SoldierDTO updateSoldier(String email, Long userId, SoldierRequest updatedUser) throws SoldierException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        if (soldierRepository.existsByPersonalNumber(updatedUser.getPersonalNumber())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.PERSONAL_NUMBER_NOT_UNIQUE);
        }

        soldier.setFirstName(updatedUser.getFirstName());
        soldier.setLastName(updatedUser.getLastName());
        soldier.setPersonalNumber(updatedUser.getPersonalNumber());
        soldier.setPassword(passwordEncoder.encode(updatedUser.getPassword()));

        return new SoldierDTO(soldierRepository.save(soldier));
    }

    @Override
    public void createNewSoldier(String email, Long userId, SoldierCreateRequest newSoldierRequest)
            throws SoldierException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        if (soldierRepository.existsByEmailIgnoreCase(newSoldierRequest.getEmail())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.EMAIL_OCCUPIED);
        }

        if (!checkPosition(soldier.getPosition(), Position.valueOf(newSoldierRequest.getPosition()))) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        Soldier newSoldier = new Soldier();
        newSoldier.setAddedBy(email);
        newSoldier.setFirstName(newSoldierRequest.getFirstName());
        newSoldier.setLastName(newSoldierRequest.getLastName());
        newSoldier.setPersonalNumber(newSoldierRequest.getPersonalNumber());
        newSoldier.setPassword(passwordEncoder.encode(newSoldierRequest.getPassword()));
        newSoldier.setEmail(newSoldierRequest.getEmail());
        newSoldier.setPosition(Position.valueOf(newSoldierRequest.getPosition()));

        soldierRepository.save(newSoldier);
    }

    @Override
    public void createBrigadeCommander(String name, Long adminId, SoldierCreateRequest newSoldierRequest)
            throws UserException, SoldierException {
        var admin = authUtil.checkAdminByEmailAndId(name, adminId);

        if (soldierRepository.existsByEmailIgnoreCase(newSoldierRequest.getEmail())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.EMAIL_OCCUPIED);
        }

        Soldier newSoldier = new Soldier();
        newSoldier.setAddedBy(admin.getEmail());
        newSoldier.setFirstName(newSoldierRequest.getFirstName());
        newSoldier.setLastName(newSoldierRequest.getLastName());
        newSoldier.setPersonalNumber(newSoldierRequest.getPersonalNumber());
        newSoldier.setPassword(passwordEncoder.encode(newSoldierRequest.getPassword()));
        newSoldier.setEmail(newSoldierRequest.getEmail());
        newSoldier.setPosition(Position.BRIGADE_COMMANDER);

        soldierRepository.save(newSoldier);
    }


    private boolean checkPosition(Position creatorPosition, Position position) {
        return switch (creatorPosition) {
            case Position.BRIGADE_COMMANDER -> position == Position.BATTALION_COMMANDER;
            case Position.BATTALION_COMMANDER -> position == Position.COMPANY_COMMANDER;
            case Position.COMPANY_COMMANDER -> position == Position.PLATOON_COMMANDER;
            case PLATOON_COMMANDER -> false;
        };
    }
}
