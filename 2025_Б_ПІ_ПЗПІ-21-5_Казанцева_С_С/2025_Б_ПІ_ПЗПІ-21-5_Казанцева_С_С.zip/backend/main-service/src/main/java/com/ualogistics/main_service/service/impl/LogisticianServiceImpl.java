package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.exception.ResourceException;
import com.ualogistics.main_service.exception.UnitException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.entity.Logistician;
import com.ualogistics.main_service.model.entity.ResourceStock;
import com.ualogistics.main_service.model.entity.Unit;
import com.ualogistics.main_service.model.request.LogisticianCreateRequest;
import com.ualogistics.main_service.model.request.ResourceQuantity;
import com.ualogistics.main_service.model.request.UnitResourcesRequest;
import com.ualogistics.main_service.repository.LogisticianRepository;
import com.ualogistics.main_service.repository.ResourceStockRepository;
import com.ualogistics.main_service.repository.UnitRepository;
import com.ualogistics.main_service.repository.mongo.ResourceRepository;
import com.ualogistics.main_service.service.LogisticianService;
import com.ualogistics.main_service.util.AuthUtil;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class LogisticianServiceImpl implements LogisticianService {

    private final LogisticianRepository logisticianRepository;
    private final ResourceStockRepository resourceStockRepository;
    private final ResourceRepository resourceRepository;
    private final UnitRepository unitRepository;
    private PasswordEncoder passwordEncoder;
    private AuthUtil authUtil;

    @Override
    public void createNewLogistician(String email, Long adminId, LogisticianCreateRequest newLogistician)
            throws UserException {
        var admin = authUtil.checkAdminByEmailAndId(email, adminId);

        Logistician logistician = new Logistician();
        logistician.setAddedBy(admin.getEmail());
        logistician.setFirstName(newLogistician.getFirstName());
        logistician.setLastName(newLogistician.getLastName());
        logistician.setPassword(passwordEncoder.encode(newLogistician.getPassword()));
        logistician.setEmail(newLogistician.getEmail());

        logisticianRepository.save(logistician);
    }

    @Override
    public void setUpResourcesForUnit(String email, Long logId, Long unitId, UnitResourcesRequest resources)
            throws UserException, ResourceException, UnitException {
        authUtil.checkLogisticianByEmailAndId(email, logId);

        Unit unit = unitRepository.findById(unitId).orElseThrow(
                () -> new UnitException(UnitException.UnitExceptionProfile.UNIT_NOT_FOUND)
        );

        if (!resources.getResources().isEmpty()) {

            List<ResourceStock> data = new ArrayList<>();

            for (ResourceQuantity elem : resources.getResources()) {

                var resource = resourceRepository.findById(elem.getResourceId()).orElseThrow(
                        () -> new ResourceException(
                                ResourceException.ResourceExceptionProfile.RESOURCE_NOT_FOUND)
                );

                ResourceStock resourceStock = new ResourceStock();
                resourceStock.setQuantity(elem.getQuantity());
                resourceStock.setResourceId(resource.getId());
                resourceStock.setUnit(unit);

                data.add(resourceStock);
            }

            resourceStockRepository.saveAll(data);
        }
    }
}
