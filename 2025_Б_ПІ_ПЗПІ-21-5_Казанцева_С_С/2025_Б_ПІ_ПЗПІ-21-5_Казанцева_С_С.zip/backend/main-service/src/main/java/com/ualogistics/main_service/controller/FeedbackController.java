package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.exception.FeedbackException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.FeedbackRequest;
import com.ualogistics.main_service.model.response.FeedbackDTO;
import com.ualogistics.main_service.service.FeedbackService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class FeedbackController {

    private FeedbackService feedbackService;

    @PostMapping("/api/users/{user-id}/feedbacks")
    public FeedbackDTO createFeedback(Authentication auth,
                                      @PathVariable("user-id") Long userId,
                                      @Valid @RequestBody FeedbackRequest feedback) throws SoldierException {
        return feedbackService.createFeedback(auth.getName(), userId, feedback);
    }

    @PatchMapping("/api/admins/{admin-id}/feedbacks/{feedback-id}/status/{status}")
    public FeedbackDTO updateFeedbackStatus(Authentication auth,
                                            @PathVariable("admin-id") Long adminId,
                                            @PathVariable("feedback-id") Long feedbackId,
                                            @PathVariable("status") String status)
            throws FeedbackException, UserException {
        return feedbackService.updateFeedbackStatus(auth.getName(), adminId, feedbackId, status);
    }

    @GetMapping("/api/admins/{admin-id}/feedbacks/{feedback-id}")
    public FeedbackDTO getFeedback(Authentication auth,
                                   @PathVariable("admin-id") Long adminId,
                                   @PathVariable("feedback-id") Long feedbackId)
            throws FeedbackException, UserException {
        return feedbackService.getFeedback(auth.getName(), adminId, feedbackId);
    }

    @GetMapping("/api/admins/{admin-id}/feedbacks")
    public List<FeedbackDTO> getAllFeedbacks(Authentication auth,
                                             @PathVariable("admin-id") Long adminId) throws UserException {
        return feedbackService.getAllFeedbacks(auth.getName(), adminId);
    }
}
