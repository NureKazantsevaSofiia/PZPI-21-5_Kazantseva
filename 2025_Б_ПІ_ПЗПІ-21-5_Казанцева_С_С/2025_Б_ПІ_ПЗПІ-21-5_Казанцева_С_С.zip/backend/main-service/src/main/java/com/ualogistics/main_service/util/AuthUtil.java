package com.ualogistics.main_service.util;

import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.entity.Admin;
import com.ualogistics.main_service.model.entity.Logistician;
import com.ualogistics.main_service.model.entity.Soldier;
import com.ualogistics.main_service.model.enums.Role;
import com.ualogistics.main_service.repository.AdminRepository;
import com.ualogistics.main_service.repository.LogisticianRepository;
import com.ualogistics.main_service.repository.SoldierRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class AuthUtil {

    private AdminRepository adminRepository;
    private SoldierRepository soldierRepository;
    private LogisticianRepository logisticianRepository;

    public Soldier findSoldierByEmailAndId(String email, Long userId) throws SoldierException {
        var soldier = soldierRepository.findById(userId).orElseThrow(
                () -> new SoldierException(SoldierException.SoldierExceptionProfile.SOLDIER_NOT_FOUND));

        if (!soldier.getEmail().equals(email)) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.SOLDIER_ACCESS_FORBIDDEN);
        }

        return soldier;
    }

    public Logistician checkLogisticianByEmailAndId(String email, Long logId) throws UserException {
        var logistician = logisticianRepository.findById(logId).orElseThrow(
                () -> new UserException(UserException.UserExceptionProfile.LOGISTICIAN_NOT_FOUND));

        if (!logistician.getEmail().equals(email)) {
            throw new UserException(UserException.UserExceptionProfile.EMAIL_MISMATCH);
        }

        return logistician;
    }

    public Admin checkAdminByEmailAndId(String email, Long adminId) throws UserException {
        var admin = adminRepository.findById(adminId).orElseThrow(
                () -> new UserException(UserException.UserExceptionProfile.ADMIN_NOT_FOUND));

        if (!admin.getEmail().equals(email)) {
            throw new UserException(UserException.UserExceptionProfile.EMAIL_MISMATCH);
        }

        return admin;
    }

    public void checkAdminByEmailAndChief(String email, Long adminId) throws UserException {
        var admin = adminRepository.findByEmailIgnoreCase(email).orElseThrow(
                () -> new UserException(UserException.UserExceptionProfile.ADMIN_NOT_FOUND));

        if (!admin.getId().equals(adminId)) {
            throw new UserException(UserException.UserExceptionProfile.PERMISSION_DENIED);
        }

        if (!Role.CHIEF_ADMIN.equals(admin.getRole())) {
            throw new UserException(UserException.UserExceptionProfile.NOT_CHIEF_ADMIN);
        }
    }
}
