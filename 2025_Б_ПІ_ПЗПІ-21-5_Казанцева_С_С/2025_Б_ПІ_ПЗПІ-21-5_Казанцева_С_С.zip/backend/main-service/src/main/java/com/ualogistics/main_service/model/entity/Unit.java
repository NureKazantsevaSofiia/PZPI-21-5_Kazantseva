package com.ualogistics.main_service.model.entity;

import com.ualogistics.main_service.model.enums.UnitType;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "units")
public class Unit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "unit_id")
    private Long id;

    @Column(name = "unit_name")
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "unit_type")
    private UnitType type;

    @Column(name = "soldier_amount")
    private Integer soldierAmount;

    @OneToMany(mappedBy = "unit")
    private List<Soldier> soldiers;

    @OneToMany(mappedBy = "unit")
    private List<Mission> missions;

    @OneToMany(mappedBy = "unit")
    private List<Feedback> feedbacks;

    @ManyToOne
    @JoinColumn(name = "parent_unit_id")
    private Unit parentUnit;

    @OneToMany(mappedBy = "parentUnit")
    private List<Unit> subUnits;
}
