package com.ualogistics.main_service.exception;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

public class UnitException extends Exception {

    private final UnitExceptionProfile unitExceptionProfile;

    public UnitException(UnitExceptionProfile unitExceptionProfile) {
        super(unitExceptionProfile.exceptionMessage);
        this.unitExceptionProfile = unitExceptionProfile;
    }

    public String getName() {
        return unitExceptionProfile.exceptionName;
    }

    public HttpStatus getResponseStatus() {
        return unitExceptionProfile.responseStatus;
    }

    @AllArgsConstructor
    public enum UnitExceptionProfile {

        UNIT_NOT_FOUND("unit_not_found",
                "Unit is not found.", HttpStatus.NOT_FOUND),

        UNIT_NAME_NOT_UNIQUE("unit_name_not_unique",
                "Unit name should be unique.", HttpStatus.BAD_REQUEST);

        private final String exceptionName;
        private final String exceptionMessage;
        private final HttpStatus responseStatus;
    }
}
