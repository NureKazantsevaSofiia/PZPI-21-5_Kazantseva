package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.exception.ResourceException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.ResourceNewRequest;
import com.ualogistics.main_service.model.response.RequestResourceDTO;
import com.ualogistics.main_service.model.response.ResourceResponse;
import com.ualogistics.main_service.service.ResourceService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class ResourceController {

    private ResourceService resourceService;

    @PostMapping("/api/admins/{admin-id}/resources")
    public ResourceResponse addResource(Authentication auth,
                                        @PathVariable("admin-id") Long adminId,
                                        @Valid @RequestBody ResourceNewRequest resource) throws UserException {
        return resourceService.addResource(auth.getName(), adminId, resource);
    }

    @PatchMapping("/api/admins/{admin-id}/resources/{resource-id}")
    public ResourceResponse updateResource(Authentication auth,
                                           @PathVariable("admin-id") Long adminId,
                                           @PathVariable("resource-id") String resourceId,
                                           @Valid @RequestBody ResourceNewRequest resource)
            throws ResourceException, UserException {
        return resourceService.updateResource(auth.getName(), adminId, resourceId, resource);
    }

    @GetMapping("/api/users/{user-id}/resources/{resource-id}")
    public ResourceResponse getResource(Authentication auth,
                                        @PathVariable("user-id") Long userId,
                                        @PathVariable("resource-id") String resourceId)
            throws ResourceException, SoldierException {
        return resourceService.getResource(auth.getName(), userId, resourceId);
    }

    @GetMapping("/api/users/{user-id}/resources-list")
    public List<ResourceResponse> getAllResources(Authentication auth,
                                                  @PathVariable("user-id") Long userId)
            throws SoldierException {
        return resourceService.getAllResources(auth.getName(), userId);
    }

    @GetMapping("/api/users/{user-id}/resources")
    public List<RequestResourceDTO> getAllResourcesByUnit(Authentication auth,
                                                          @PathVariable("user-id") Long userId)
            throws SoldierException {
        return resourceService.getAllResourcesByUnit(auth.getName(), userId);
    }

    @GetMapping("/api/users/{user-id}/resources/search/{name}")
    public List<ResourceResponse> searchResourcesByName(Authentication auth,
                                                        @PathVariable("user-id") Long userId,
                                                        @PathVariable("name") String name)
            throws SoldierException {
        return resourceService.searchResourcesByName(auth.getName(), userId, name);
    }
}
