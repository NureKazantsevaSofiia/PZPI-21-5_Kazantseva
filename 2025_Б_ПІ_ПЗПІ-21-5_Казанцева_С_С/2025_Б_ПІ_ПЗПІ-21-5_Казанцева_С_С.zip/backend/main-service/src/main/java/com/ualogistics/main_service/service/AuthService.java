package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.AuthException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.UserRequest;
import com.ualogistics.main_service.model.response.LoginResponse;
import com.ualogistics.main_service.model.response.UserResponse;
import org.springframework.security.core.Authentication;

public interface AuthService {

    LoginResponse login(Authentication auth) throws UserException;

    UserResponse register(UserRequest newUser) throws AuthException;
}
