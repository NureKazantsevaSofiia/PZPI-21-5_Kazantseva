package com.ualogistics.main_service.repository;

import com.ualogistics.main_service.model.entity.RequestResource;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RequestResourceRepository extends JpaRepository<RequestResource, Long> {

    List<RequestResource> findAllByLogisticsRequestId(Long logisticsRequestId);
}
