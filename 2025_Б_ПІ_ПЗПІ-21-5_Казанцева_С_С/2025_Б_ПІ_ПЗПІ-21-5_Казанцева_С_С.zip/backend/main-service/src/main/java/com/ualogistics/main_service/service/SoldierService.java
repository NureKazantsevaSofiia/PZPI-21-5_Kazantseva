package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.SoldierCreateRequest;
import com.ualogistics.main_service.model.request.SoldierRequest;
import com.ualogistics.main_service.model.response.SoldierDTO;

import java.util.List;

public interface SoldierService {

    List<String> getPositions(String email, Long userId) throws SoldierException;

    SoldierDTO getSoldier(String email, Long userId) throws SoldierException;

    SoldierDTO updateSoldier(String email, Long userId, SoldierRequest updatedUser)
            throws SoldierException;

    void createNewSoldier(String email, Long userId, SoldierCreateRequest newSoldier) throws SoldierException;

    void createBrigadeCommander(String name, Long adminId, SoldierCreateRequest newSoldier) throws UserException, SoldierException;
}
