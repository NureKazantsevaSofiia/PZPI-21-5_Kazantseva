package com.ualogistics.main_service.util.swagger;

import com.ualogistics.main_service.exception.AuthException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.UpdateAdminRequest;
import com.ualogistics.main_service.model.response.AdminDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Admin API", description = "API for managing administrators")
public interface AdminAPI {

    @Operation(summary = "Get Admin details",
            description = "Fetches the details of a specific admin by their ID.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Admin details retrieved successfully",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = AdminDTO.class))),
                    @ApiResponse(responseCode = "403",
                            description = "Email provided does not match the user's email", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Admin is not found", content = @Content),
            },
            parameters = {
                    @Parameter(
                            name = "Authorization",
                            description = "Bearer token",
                            in = ParameterIn.HEADER,
                            required = true,
                            schema = @Schema(type = "string")
                    )
            })
    @GetMapping("/api/admins/{admin-id}")
    AdminDTO getAdmin(Authentication auth,
                      @Parameter(description = "ID of the admin to fetch")
                      @PathVariable("admin-id") Long adminId) throws UserException;


    @Operation(summary = "Get Approved Admins",
            description = "Fetches a list of approved admins.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Approved admins retrieved successfully",
                            content = @Content(mediaType = "application/json",
                                    array = @ArraySchema(schema = @Schema(implementation = AdminDTO.class)))),
                    @ApiResponse(responseCode = "404", description = "Admin is not found", content = @Content),
            },
            parameters = {
                    @Parameter(
                            name = "Authorization",
                            description = "Bearer token",
                            in = ParameterIn.HEADER,
                            required = true,
                            schema = @Schema(type = "string")
                    )
            })
    @GetMapping("/api/admins/approved")
    List<AdminDTO> getApprovedAdmins(Authentication auth) throws UserException;


    @Operation(summary = "Get Not Approved Admins",
            description = "Fetches a list of admins that are not yet approved.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Not approved admins retrieved successfully",
                            content = @Content(mediaType = "application/json",
                                    array = @ArraySchema(schema = @Schema(implementation = AdminDTO.class)))),
                    @ApiResponse(responseCode = "404", description = "Admin is not found", content = @Content)
            },
            parameters = {
                    @Parameter(
                            name = "Authorization",
                            description = "Bearer token",
                            in = ParameterIn.HEADER,
                            required = true,
                            schema = @Schema(type = "string")
                    )
            })
    @GetMapping("/api/admins/not-approved")
    List<AdminDTO> getNotApprovedAdmins(Authentication auth) throws UserException;


    @Operation(summary = "Add a New Admin",
            description = "Adds a new admin by associating their email with an existing admin ID.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "New admin added successfully", content = @Content),
                    @ApiResponse(responseCode = "400", description = "User with such email already exists", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Email provided does not match the user's email", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Admin is not found", content = @Content),
            },
            parameters = {
                    @Parameter(
                            name = "Authorization",
                            description = "Bearer token",
                            in = ParameterIn.HEADER,
                            required = true,
                            schema = @Schema(type = "string")
                    )
            })
    @PostMapping("/api/admins/{admin-id}/add/{email}")
    void addAdmin(Authentication auth, @PathVariable("admin-id") Long adminId, @PathVariable("email") String email) throws UserException, SecurityException, AuthException;


    @Operation(summary = "Approve an Admin",
            description = "Approves a new admin by their ID and the ID of the existing admin.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Admin approved successfully",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(type = "string"))),
                    @ApiResponse(responseCode = "403", description = "Permission denied", content = @Content),
                    @ApiResponse(responseCode = "403", description = "You are not chief admin", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Admin is not found", content = @Content)
            },
            parameters = {
                    @Parameter(
                            name = "Authorization",
                            description = "Bearer token",
                            in = ParameterIn.HEADER,
                            required = true,
                            schema = @Schema(type = "string")
                    )
            })
    @PostMapping("/api/admins/{admin-id}/approve/{new-admin-id}")
    String approveAdmin(Authentication auth, @PathVariable("admin-id") Long adminId, @PathVariable("new-admin-id") Long newAdminId) throws UserException;

    @Operation(summary = "Decline an Admin",
            description = "Declines a new admin request by their ID and the ID of the existing admin.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Admin declined successfully", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Permission denied", content = @Content),
                    @ApiResponse(responseCode = "403", description = "You are not chief admin", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Admin is not found", content = @Content)
            },
            parameters = {
                    @Parameter(
                            name = "Authorization",
                            description = "Bearer token",
                            in = ParameterIn.HEADER,
                            required = true,
                            schema = @Schema(type = "string")
                    )
            })
    @PostMapping("/api/admins/{admin-id}/decline/{new-admin-id}")
    void declineAdmin(Authentication auth, @PathVariable("admin-id") Long adminId, @PathVariable("new-admin-id") Long newAdminId) throws UserException;


    @Operation(summary = "Update Admin details",
            description = "Updates the details of a specific admin.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Admin updated successfully", content = @Content),
                    @ApiResponse(responseCode = "400", description = "Something went wrong", content = @Content),
                    @ApiResponse(responseCode = "403", description = "Email provided does not match the user's email", content = @Content),
                    @ApiResponse(responseCode = "404", description = "Admin is not found", content = @Content),
            },
            parameters = {
                    @Parameter(
                            name = "Authorization",
                            description = "Bearer token",
                            in = ParameterIn.HEADER,
                            required = true,
                            schema = @Schema(type = "string")
                    )
            })
    @PatchMapping("/api/admins/{admin-id}")
    void updateAdmin(Authentication auth, @PathVariable("admin-id") Long adminId, @RequestBody UpdateAdminRequest updatedAdmin) throws UserException;
}
