package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.Admin;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AdminDTO {

    private Long id;

    private String firstName;

    private String lastName;

    private String email;

    private LocalDateTime dateOfApproving;

    private LocalDateTime dateOfAdding;

    private String addedBy;

    private boolean approved;

    private boolean newAccount;

    public AdminDTO(Admin admin) {
        this.id = admin.getId();
        this.firstName = admin.getFirstName();
        this.lastName = admin.getLastName();
        this.email = admin.getEmail();
        this.dateOfApproving = admin.getDateOfApproving();
        this.dateOfAdding = admin.getDateOfAdding();
        this.addedBy = admin.getAddedBy();
        this.approved = admin.isApproved();
        this.newAccount = admin.isNewAccount();
    }
}
