package com.ualogistics.main_service.model.response;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class LogisticsRequestDTO {

    private Long id;

    private String status;

    private ShortUnitDTO unit;

    private Long missionId;

    private List<RequestResourceDTO> resources;
}
