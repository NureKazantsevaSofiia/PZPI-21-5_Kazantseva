package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.SoldierCreateRequest;
import com.ualogistics.main_service.model.request.SoldierRequest;
import com.ualogistics.main_service.model.response.SoldierDTO;
import com.ualogistics.main_service.service.SoldierService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class SoldierController {

    private SoldierService soldierService;

    @GetMapping("/api/users/{user-id}/positions")
    public List<String> getPositions(Authentication auth,
                                     @PathVariable("user-id") Long userId) throws SoldierException {
        return soldierService.getPositions(auth.getName(), userId);
    }

    @GetMapping("/api/users/{user-id}")
    public SoldierDTO getSoldier(Authentication auth,
                                 @PathVariable("user-id") Long userId) throws SoldierException {
        return soldierService.getSoldier(auth.getName(), userId);
    }

    @PatchMapping("/api/users/{user-id}")
    public SoldierDTO updateSoldier(Authentication auth,
                                    @PathVariable("user-id") Long userId,
                                    @Valid @RequestBody SoldierRequest updatedUser) throws SoldierException {
        return soldierService.updateSoldier(auth.getName(), userId, updatedUser);
    }

    @PostMapping("/api/users/{user-id}/soldiers")
    public void createNewSoldier(Authentication auth,
                                 @PathVariable("user-id") Long userId,
                                 @Valid @RequestBody SoldierCreateRequest newSoldier)
            throws SoldierException {
        soldierService.createNewSoldier(auth.getName(), userId, newSoldier);
    }

    @PostMapping("/api/admins/{admin-id}/soldiers")
    public void createBrigadeCommander(Authentication auth,
                                       @PathVariable("admin-id") Long adminId,
                                       @Valid @RequestBody SoldierCreateRequest newSoldier)
            throws SoldierException, UserException {
        soldierService.createBrigadeCommander(auth.getName(), adminId, newSoldier);
    }
}
