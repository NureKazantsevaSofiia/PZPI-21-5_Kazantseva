package com.ualogistics.main_service.model.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UnitCreateRequest {

    @NotEmpty
    @NotNull
    @Size(min = 3, max = 60)
    private String name;

    @NotEmpty
    @NotNull
    private String type;

    @Positive
    private int soldierAmount;
}
