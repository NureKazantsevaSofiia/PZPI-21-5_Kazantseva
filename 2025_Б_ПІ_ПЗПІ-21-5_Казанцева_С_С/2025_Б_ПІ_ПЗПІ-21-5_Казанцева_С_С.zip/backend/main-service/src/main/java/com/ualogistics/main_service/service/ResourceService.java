package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.ResourceException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.ResourceNewRequest;
import com.ualogistics.main_service.model.response.RequestResourceDTO;
import com.ualogistics.main_service.model.response.ResourceResponse;

import java.util.List;

public interface ResourceService {

    ResourceResponse addResource(String email, Long userId, ResourceNewRequest resource) throws UserException;

    ResourceResponse updateResource(String email, Long userId, String resourceId, ResourceNewRequest resource)
            throws UserException, ResourceException;

//    void updateQuantityResource(String email, Long userId, Long unitId, Long requestResourceId, int quantity)
//            throws ResourceException, SoldierException, UnitException;

    ResourceResponse getResource(String email, Long userId, String resourceId)
            throws ResourceException, SoldierException;

    List<ResourceResponse> getAllResources(String email, Long userId) throws SoldierException;

    List<ResourceResponse> searchResourcesByName(String email, Long userId, String name) throws SoldierException;

    List<RequestResourceDTO> getAllResourcesByUnit(String email, Long userId) throws SoldierException;
}
