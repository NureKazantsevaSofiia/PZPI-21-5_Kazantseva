package com.ualogistics.main_service.model.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ResourceQuantity {

    @NotEmpty
    @NotNull
    private String resourceId;

    @NotEmpty
    @NotNull
    private int quantity;
}
