package com.ualogistics.main_service.repository;

import com.ualogistics.main_service.model.entity.Unit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UnitRepository extends JpaRepository<Unit, Long> {

    boolean existsByName(String name);
}
