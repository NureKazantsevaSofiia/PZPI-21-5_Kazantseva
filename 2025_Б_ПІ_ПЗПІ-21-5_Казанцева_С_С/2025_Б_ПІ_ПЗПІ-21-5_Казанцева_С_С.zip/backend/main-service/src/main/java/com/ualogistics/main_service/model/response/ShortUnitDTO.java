package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.Unit;
import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ShortUnitDTO {

    private Long id;

    private String name;

    private String type;

    public ShortUnitDTO(Unit unit) {
        this.id = unit.getId();
        this.name = unit.getName();
        this.type = unit.getType().name();
    }
}
