package com.ualogistics.main_service.model.response;

import com.ualogistics.main_service.model.entity.Soldier;
import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SoldierDTO {

    private String firstName;

    private String lastName;

    private String email;

    private String position;

    private String unit;

    public SoldierDTO(Soldier soldier) {
        this.firstName = soldier.getFirstName();
        this.lastName = soldier.getLastName();
        this.email = soldier.getEmail();
        this.position = soldier.getPosition().toString();
        this.unit = soldier.getUnit().getName();
    }
}
