package com.ualogistics.main_service.model.enums;

public enum FeedbackType {

    BUG_REPORT,
    FEATURE_REQUEST,
    CATEGORY_REQUEST
}
