package com.ualogistics.main_service.repository;

import com.ualogistics.main_service.model.entity.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
}
