package com.ualogistics.main_service.exception;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

public class LogisticRequestException extends Exception {

    private final LogisticRequestExceptionProfile logisticRequestExceptionProfile;

    public LogisticRequestException(LogisticRequestExceptionProfile logisticRequestExceptionProfile) {
        super(logisticRequestExceptionProfile.exceptionMessage);
        this.logisticRequestExceptionProfile = logisticRequestExceptionProfile;
    }

    public String getName() {
        return logisticRequestExceptionProfile.exceptionName;
    }

    public HttpStatus getResponseStatus() {
        return logisticRequestExceptionProfile.responseStatus;
    }

    @AllArgsConstructor
    public enum LogisticRequestExceptionProfile {

        LOGISTICS_REQUEST_NOT_FOUND("logistics_request_not_found",
                "Logistics Request is not found.", HttpStatus.NOT_FOUND);

        private final String exceptionName;
        private final String exceptionMessage;
        private final HttpStatus responseStatus;
    }
}
