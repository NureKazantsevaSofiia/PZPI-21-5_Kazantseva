package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.exception.*;
import com.ualogistics.main_service.model.entity.*;
import com.ualogistics.main_service.model.enums.Status;
import com.ualogistics.main_service.model.request.LogisticsRequestReq;
import com.ualogistics.main_service.model.request.ResourceQuantity;
import com.ualogistics.main_service.model.response.LogisticsRequestDTO;
import com.ualogistics.main_service.model.response.RequestResourceDTO;
import com.ualogistics.main_service.model.response.ShortUnitDTO;
import com.ualogistics.main_service.repository.*;
import com.ualogistics.main_service.repository.mongo.ResourceRepository;
import com.ualogistics.main_service.service.LogisticsRequestService;
import com.ualogistics.main_service.util.AuthUtil;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class LogisticsRequestServiceImpl implements LogisticsRequestService {

    private AuthUtil authUtil;
    private LogisticsRequestRepository logisticsRequestRepository;
    private RequestResourceRepository requestResourceRepository;
    private ResourceRepository resourceRepository;
    private MissionRepository missionRepository;
    private ResourceStockRepository resourceStockRepository;
    private UnitRepository unitRepository;

    @Override
    public List<String> getRequestStatuses(String email, Long userId) throws SoldierException {
        authUtil.findSoldierByEmailAndId(email, userId);

        return List.of(Arrays.stream(Status.values()).map(Status::name).toArray(String[]::new));
    }

    @Override
    public LogisticsRequestDTO createLogisticsRequest(String email, Long userId, Long missionId,
                                                      LogisticsRequestReq newRequest)
            throws SoldierException, MissionException, ResourceException, LogisticRequestException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        if (!soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        LogisticsRequest request = new LogisticsRequest();
        request.setUnit(soldier.getUnit());
        request.setMission(mission);
        request.setStatus(Status.valueOf(newRequest.getStatus()));
        request.setRequestsResources(new ArrayList<>());

        LogisticsRequest createdRequest = logisticsRequestRepository.save(request);

        if (!newRequest.getResources().isEmpty()) {

            List<RequestResource> data = new ArrayList<>();

            for (ResourceQuantity elem : newRequest.getResources()) {

                var resource = resourceRepository.findById(elem.getResourceId()).orElseThrow(
                        () -> new ResourceException(
                                ResourceException.ResourceExceptionProfile.RESOURCE_NOT_FOUND)
                );

                RequestResource requestResource = new RequestResource();
                requestResource.setQuantity(elem.getQuantity());
                requestResource.setResourceId(resource.getId());
                requestResource.setLogisticsRequest(createdRequest);

                data.add(requestResource);
            }

            requestResourceRepository.saveAll(data);

            return getLogisticsRequest(email, userId, missionId, createdRequest.getId());
        } else {
            return toLogisticsRequestDTO(createdRequest);
        }
    }

    @Override
    public LogisticsRequestDTO updateStatusLogisticsRequest(String email, Long userId, Long missionId,
                                                            Long logisticsRequestId, String status)
            throws SoldierException, MissionException, LogisticRequestException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        LogisticsRequest logisticsRequest = logisticsRequestRepository.findById(logisticsRequestId)
                .orElseThrow(() -> new LogisticRequestException(LogisticRequestException.
                        LogisticRequestExceptionProfile.LOGISTICS_REQUEST_NOT_FOUND)
                );

        if (!logisticsRequest.getUnit().getId().equals(mission.getUnit().getId()) ||
                !soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        logisticsRequest.setStatus(Status.valueOf(status));

        return toLogisticsRequestDTO(logisticsRequestRepository.save(logisticsRequest));
    }

    @Transactional
    @Override
    public LogisticsRequestDTO updateLogisticsRequest(String email, Long userId, Long missionId,
                                                      Long logisticsRequestId, LogisticsRequestReq request)
            throws SoldierException, MissionException, LogisticRequestException, ResourceException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        LogisticsRequest logisticsRequest = logisticsRequestRepository.findById(logisticsRequestId)
                .orElseThrow(() -> new LogisticRequestException(LogisticRequestException.
                        LogisticRequestExceptionProfile.LOGISTICS_REQUEST_NOT_FOUND)
                );

        if (!logisticsRequest.getUnit().getId().equals(mission.getUnit().getId()) ||
                !soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        logisticsRequest.setStatus(Status.valueOf(request.getStatus()));

        List<RequestResource> resources = logisticsRequest.getRequestsResources();

        logisticsRequest.setRequestsResources(new ArrayList<>());
        LogisticsRequest updatedRequest = logisticsRequestRepository.save(logisticsRequest);

        if (!resources.isEmpty()) {
            requestResourceRepository.deleteAll(resources);
        }

        if (!request.getResources().isEmpty()) {

            List<RequestResource> data = new ArrayList<>();

            for (ResourceQuantity elem : request.getResources()) {

                var resource = resourceRepository.findById(elem.getResourceId()).orElseThrow(
                        () -> new ResourceException(
                                ResourceException.ResourceExceptionProfile.RESOURCE_NOT_FOUND)
                );

                RequestResource requestResource = new RequestResource();
                requestResource.setQuantity(elem.getQuantity());
                requestResource.setResourceId(resource.getId());
                requestResource.setLogisticsRequest(updatedRequest);

                data.add(requestResource);
            }

            requestResourceRepository.saveAll(data);

            return getLogisticsRequest(email, userId, missionId, updatedRequest.getId());
        } else {
            return toLogisticsRequestDTO(updatedRequest);
        }
    }

    @Override
    public LogisticsRequestDTO getLogisticsRequest(String email, Long userId, Long missionId, Long requestId)
            throws SoldierException, MissionException, LogisticRequestException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        LogisticsRequest logisticsRequest = logisticsRequestRepository.findById(requestId)
                .orElseThrow(() -> new LogisticRequestException(LogisticRequestException.
                        LogisticRequestExceptionProfile.LOGISTICS_REQUEST_NOT_FOUND)
                );

        if (!logisticsRequest.getUnit().getId().equals(mission.getUnit().getId()) ||
                !soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        return toLogisticsRequestDTO(logisticsRequest);
    }

    @Override
    public List<LogisticsRequestDTO> getLogisticsRequestsByMission(String email, Long userId, Long missionId)
            throws SoldierException, MissionException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        if (!soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        return logisticsRequestRepository.findByMissionId(missionId).stream()
                .map(this::toLogisticsRequestDTO).collect(Collectors.toList());
    }

    @Override
    public List<LogisticsRequestDTO> getLogisticsRequestsByUnit(String email, Long userId, Long unitId)
            throws SoldierException, UnitException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Unit unit = unitRepository.findById(unitId).orElseThrow(
                () -> new UnitException(UnitException.UnitExceptionProfile.UNIT_NOT_FOUND)
        );

        if (!soldier.getUnit().getId().equals(unit.getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        return logisticsRequestRepository.findByUnitId(unit.getId()).stream()
                .map(this::toLogisticsRequestDTO).collect(Collectors.toList());
    }

    @Override
    public void approveExecutionOfLogisticsRequest(String email, Long userId, Long missionId, Long requestId) throws SoldierException, MissionException, LogisticRequestException, ResourceException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        Mission mission = missionRepository.findById(missionId).orElseThrow(
                () -> new MissionException(MissionException.MissionExceptionProfile.MISSION_NOT_FOUND)
        );

        if (!soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        LogisticsRequest logisticsRequest = logisticsRequestRepository.findById(requestId)
                .orElseThrow(() -> new LogisticRequestException(LogisticRequestException.
                        LogisticRequestExceptionProfile.LOGISTICS_REQUEST_NOT_FOUND)
                );

        if (!logisticsRequest.getUnit().getId().equals(mission.getUnit().getId()) ||
                !soldier.getUnit().getId().equals(mission.getUnit().getId())) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        if (logisticsRequest.getStatus() == Status.DELIVERED) {

            if (!logisticsRequest.getRequestsResources().isEmpty()) {

                List<ResourceStock> data = new ArrayList<>();

                for (RequestResource elem : logisticsRequest.getRequestsResources()) {

                    var resource = resourceRepository.findById(elem.getResourceId()).orElseThrow(
                            () -> new ResourceException(
                                    ResourceException.ResourceExceptionProfile.RESOURCE_NOT_FOUND)
                    );

                    ResourceStock resourceStock = new ResourceStock();
                    resourceStock.setQuantity(elem.getQuantity());
                    resourceStock.setResourceId(resource.getId());
                    resourceStock.setUnit(soldier.getUnit());

                    data.add(resourceStock);
                }

                resourceStockRepository.saveAll(data);
            }

            logisticsRequest.setStatus(Status.RECEIVED);
            logisticsRequestRepository.save(logisticsRequest);
        } else {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

    }

    private LogisticsRequestDTO toLogisticsRequestDTO(LogisticsRequest logisticsRequest) {
        var resources = new ArrayList<RequestResourceDTO>();
        logisticsRequest.getRequestsResources().forEach(res -> {
            if (res.getResourceId() != null) {
                resourceRepository.findById(res.getResourceId())
                        .ifPresent(resource -> resources.add(new RequestResourceDTO(res, resource)));
            }
        });

        return LogisticsRequestDTO.builder()
                .id(logisticsRequest.getId())
                .status(logisticsRequest.getStatus().toString())
                .unit(new ShortUnitDTO(logisticsRequest.getUnit()))
                .missionId(logisticsRequest.getMission().getId())
                .resources(resources)
                .build();
    }

}
