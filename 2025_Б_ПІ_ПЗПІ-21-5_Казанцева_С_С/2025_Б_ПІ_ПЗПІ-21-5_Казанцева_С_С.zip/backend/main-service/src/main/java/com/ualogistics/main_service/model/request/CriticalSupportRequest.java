package com.ualogistics.main_service.model.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CriticalSupportRequest {

    private Long userId;

    @NotEmpty
    @NotNull
    private String battleGroupName;

    @NotEmpty
    @NotNull
    private String position;

    @NotEmpty
    @NotNull
    private String description;
}
