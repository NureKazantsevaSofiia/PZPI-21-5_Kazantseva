package com.ualogistics.main_service.exception;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

public class ResourceException extends Exception {

    private final ResourceExceptionProfile resourceExceptionProfile;

    public ResourceException(ResourceExceptionProfile resourceExceptionProfile) {
        super(resourceExceptionProfile.exceptionMessage);
        this.resourceExceptionProfile = resourceExceptionProfile;
    }

    public String getName() {
        return resourceExceptionProfile.exceptionName;
    }

    public HttpStatus getResponseStatus() {
        return resourceExceptionProfile.responseStatus;
    }

    @AllArgsConstructor
    public enum ResourceExceptionProfile {

        RESOURCE_NOT_FOUND("resource_not_found",
                "Resource is not found.", HttpStatus.NOT_FOUND),

        INVALID_QUANTITY("invalid_quantity",
                "Quantity must be positive number.", HttpStatus.BAD_REQUEST);

        private final String exceptionName;
        private final String exceptionMessage;
        private final HttpStatus responseStatus;
    }
}
