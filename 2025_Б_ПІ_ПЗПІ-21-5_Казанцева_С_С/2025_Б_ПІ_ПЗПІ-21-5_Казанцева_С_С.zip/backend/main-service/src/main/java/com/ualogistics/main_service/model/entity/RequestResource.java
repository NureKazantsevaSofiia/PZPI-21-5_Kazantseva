package com.ualogistics.main_service.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "request_resource")
public class RequestResource {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "request_resource_id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "request_id")
    private LogisticsRequest logisticsRequest;

    @Column(name = "resource_id")
    private String resourceId;

    @Column(name = "quantity")
    private int quantity;
}
