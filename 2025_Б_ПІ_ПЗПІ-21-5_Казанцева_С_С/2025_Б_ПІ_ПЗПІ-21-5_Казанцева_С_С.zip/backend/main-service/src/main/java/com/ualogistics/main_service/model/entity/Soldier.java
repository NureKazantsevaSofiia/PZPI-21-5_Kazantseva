package com.ualogistics.main_service.model.entity;

import com.ualogistics.main_service.model.enums.Position;
import com.ualogistics.main_service.model.enums.Role;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@SuperBuilder
@Getter
@Setter
@AllArgsConstructor
@Table(name = "soldiers")
public class Soldier extends User {

    @Column(name = "added_by")
    private String addedBy;

    @Column(name = "personal_number")
    private String personalNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "position")
    private Position position;

    @ManyToOne
    @JoinColumn(name = "unit_id")
    private Unit unit;

    public Soldier() {
        this.setRole(Role.SOLDIER);
    }
}
