package com.ualogistics.main_service.model.enums;

public enum Role {
    SOLDIER,
    LOGISTICIAN,
    CHIEF_ADMIN,
    ADMIN
}
