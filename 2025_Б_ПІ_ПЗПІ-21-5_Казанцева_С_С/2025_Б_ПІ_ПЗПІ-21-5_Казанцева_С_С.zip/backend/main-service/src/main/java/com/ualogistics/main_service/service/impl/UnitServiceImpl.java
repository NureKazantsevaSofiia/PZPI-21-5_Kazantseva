package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UnitException;
import com.ualogistics.main_service.model.entity.Soldier;
import com.ualogistics.main_service.model.entity.Unit;
import com.ualogistics.main_service.model.enums.UnitType;
import com.ualogistics.main_service.model.request.UnitCreateRequest;
import com.ualogistics.main_service.model.request.UnitUpdateRequest;
import com.ualogistics.main_service.model.response.UnitDTO;
import com.ualogistics.main_service.repository.SoldierRepository;
import com.ualogistics.main_service.repository.UnitRepository;
import com.ualogistics.main_service.service.UnitService;
import com.ualogistics.main_service.util.AuthUtil;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
@AllArgsConstructor
public class UnitServiceImpl implements UnitService {

    private final SoldierRepository soldierRepository;
    private AuthUtil authUtil;
    private UnitRepository unitRepository;

    @Override
    public List<String> getUnitTypes(String email, Long userId) throws SoldierException {
        authUtil.findSoldierByEmailAndId(email, userId);

        return List.of(Arrays.stream(UnitType.values()).map(UnitType::name).toArray(String[]::new));
    }

    @Override
    public UnitDTO createUnit(String email, Long userId, UnitCreateRequest newUnit)
            throws SoldierException, UnitException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        if (unitRepository.existsByName(newUnit.getName())) {
            throw new UnitException(UnitException.UnitExceptionProfile.UNIT_NAME_NOT_UNIQUE);
        }

        Unit unit = new Unit();
        unit.setName(newUnit.getName());
        unit.setSoldierAmount(newUnit.getSoldierAmount());

        if (!checkUnitType(soldier.getUnit().getType(), UnitType.valueOf(newUnit.getType()))) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        unit.setType(UnitType.valueOf(newUnit.getType()));

        var createdUnit = unitRepository.save(unit);

        soldier.setUnit(createdUnit);

        soldierRepository.save(soldier);

        return new UnitDTO(createdUnit);
    }

    @Override
    public UnitDTO getUnit(String email, Long userId, Long unitId) throws SoldierException, UnitException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        if (!soldier.getUnit().getId().equals(unitId)) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        Unit unit = unitRepository.findById(unitId).orElseThrow(
                () -> new UnitException(UnitException.UnitExceptionProfile.UNIT_NOT_FOUND)
        );

        return new UnitDTO(unit);
    }

    @Override
    public UnitDTO getUnitByUser(String email, Long userId) throws SoldierException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        return new UnitDTO(soldier.getUnit());
    }

    @Override
    public UnitDTO updateUnit(String email, Long userId, Long unitId, UnitUpdateRequest updatedUnit)
            throws SoldierException, UnitException {
        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);

        if (!soldier.getUnit().getId().equals(unitId)) {
            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
        }

        if (unitRepository.existsByName(updatedUnit.getName())) {
            throw new UnitException(UnitException.UnitExceptionProfile.UNIT_NAME_NOT_UNIQUE);
        }

        Unit unit = unitRepository.findById(unitId).orElseThrow(
                () -> new UnitException(UnitException.UnitExceptionProfile.UNIT_NOT_FOUND)
        );

        unit.setName(updatedUnit.getName());

        return new UnitDTO(unitRepository.save(unit));
    }

    private boolean checkUnitType(UnitType creatorType, UnitType type) {
        return switch (creatorType) {
            case UnitType.BRIGADE -> type == UnitType.BRIGADE || type == UnitType.BATTALION;
            case UnitType.BATTALION -> type == UnitType.BATTALION || type == UnitType.COMPANY;
            case UnitType.COMPANY -> type == UnitType.COMPANY || type == UnitType.PLATOON;
            case UnitType.PLATOON -> type == UnitType.PLATOON;
        };
    }
}
