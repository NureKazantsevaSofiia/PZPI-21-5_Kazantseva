package com.ualogistics.main_service.repository.mongo;

import com.ualogistics.main_service.model.entity.mongo.Resource;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ResourceRepository extends MongoRepository<Resource, String> {

    List<Resource> findAllByNameContains(String name);

}
