package com.ualogistics.main_service.service.impl;

import com.ualogistics.main_service.exception.ResourceException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.entity.ResourceStock;
import com.ualogistics.main_service.model.entity.mongo.Resource;
import com.ualogistics.main_service.model.request.ResourceNewRequest;
import com.ualogistics.main_service.model.response.RequestResourceDTO;
import com.ualogistics.main_service.model.response.ResourceResponse;
import com.ualogistics.main_service.repository.LogisticsRequestRepository;
import com.ualogistics.main_service.repository.RequestResourceRepository;
import com.ualogistics.main_service.repository.ResourceStockRepository;
import com.ualogistics.main_service.repository.UnitRepository;
import com.ualogistics.main_service.repository.mongo.ResourceRepository;
import com.ualogistics.main_service.service.ResourceService;
import com.ualogistics.main_service.util.AuthUtil;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ResourceServiceImpl implements ResourceService {

    private final LogisticsRequestRepository logisticsRequestRepository;
    private ResourceRepository resourceRepository;
    private RequestResourceRepository requestResourceRepository;
    private ResourceStockRepository resourceStockRepository;
    private UnitRepository unitRepository;
    private AuthUtil authUtil;

    @Override
    public ResourceResponse addResource(String email, Long adminId, ResourceNewRequest resource)
            throws UserException {
        authUtil.checkAdminByEmailAndId(email, adminId);

        Resource newResource = Resource.builder()
                .name(resource.getName())
                .price(resource.getPrice())
                .build();

        return new ResourceResponse(resourceRepository.save(newResource));
    }

    @Override
    public ResourceResponse updateResource(String email, Long adminId, String resourceId,
                                           ResourceNewRequest resource)
            throws UserException, ResourceException {
        authUtil.checkAdminByEmailAndId(email, adminId);

        Resource updatedResource = resourceRepository.findById(resourceId).orElseThrow(
                () -> new ResourceException(ResourceException.ResourceExceptionProfile.RESOURCE_NOT_FOUND));

        updatedResource.setName(resource.getName());
        updatedResource.setPrice(resource.getPrice());

        return new ResourceResponse(resourceRepository.save(updatedResource));
    }

//    @Override
//    public void updateQuantityResource(String email, Long userId, Long unitId, Long resourceRequestId,
//                                       int quantity)
//            throws ResourceException, SoldierException, UnitException {
//        Soldier soldier = authUtil.findSoldierByEmailAndId(email, userId);
//
//        Unit unit = unitRepository.findById(unitId).orElseThrow(
//                () -> new UnitException(UnitException.UnitExceptionProfile.UNIT_NOT_FOUND)
//        );
//
//        RequestResource resourceRequest = requestResourceRepository.findById(resourceRequestId).orElseThrow(
//                () -> new ResourceException(ResourceException.ResourceExceptionProfile.RESOURCE_NOT_FOUND));
//
//        if (!soldier.getUnit().getId().equals(unit.getId())) {
//            throw new SoldierException(SoldierException.SoldierExceptionProfile.ACCESS_FORBIDDEN);
//        }
//
//        if (quantity < 0) {
//            throw new ResourceException(ResourceException.ResourceExceptionProfile.INVALID_QUANTITY);
//        }
//
//        resourceRequest.setQuantity(quantity);
//
//        requestResourceRepository.save(resourceRequest);
//    }

    @Override
    public ResourceResponse getResource(String email, Long userId, String resourceId)
            throws ResourceException, SoldierException {
        authUtil.findSoldierByEmailAndId(email, userId);

        Resource resource = resourceRepository.findById(resourceId).orElseThrow(
                () -> new ResourceException(ResourceException.ResourceExceptionProfile.RESOURCE_NOT_FOUND));

        return new ResourceResponse(resource);
    }

    @Override
    public List<ResourceResponse> getAllResources(String email, Long userId) throws SoldierException {
        authUtil.findSoldierByEmailAndId(email, userId);

        return resourceRepository.findAll().stream()
                .map(ResourceResponse::new)
                .collect(Collectors.toList());
    }

    @Override
    public List<ResourceResponse> searchResourcesByName(String email, Long userId, String name)
            throws SoldierException {
        authUtil.findSoldierByEmailAndId(email, userId);

        List<Resource> resources = resourceRepository.findAllByNameContains(name);

        return resources.stream().map(ResourceResponse::new).collect(Collectors.toList());
    }

    @Override
    public List<RequestResourceDTO> getAllResourcesByUnit(String email, Long userId) throws SoldierException {
        var soldier = authUtil.findSoldierByEmailAndId(email, userId);

        List<ResourceStock> stock = resourceStockRepository.findAllByUnitId(soldier.getUnit().getId());

        Map<String, Integer> grouped = new HashMap<>();
        for (ResourceStock e : stock) {
            grouped.put(e.getResourceId(), grouped.getOrDefault(e.getResourceId(), 0)
                    + e.getQuantity());
        }

        List<RequestResourceDTO> finalResult = new ArrayList<>();
        
        for (Map.Entry<String, Integer> entry : grouped.entrySet()) {
            finalResult.add(toRequestResourceDTO(entry.getKey(), entry.getValue()));
        }

        return finalResult;
    }

    private RequestResourceDTO toRequestResourceDTO(String resourceId, int quantity) {
        Resource resource = resourceRepository.findById(resourceId).orElse(null);
        if (resource != null) {
            return new RequestResourceDTO(resource, quantity);
        }
        return null;
    }
}
