package com.ualogistics.main_service.model.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class LogisticsRequestReq {

    @NotEmpty
    @NotNull
    private String status;

    @NotEmpty
    @NotNull
    private List<ResourceQuantity> resources;
}
