package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.exception.MissionException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.model.request.MissionRequest;
import com.ualogistics.main_service.model.response.FullMissionDTO;
import com.ualogistics.main_service.model.response.MissionDTO;
import com.ualogistics.main_service.service.MissionService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class MissionController {

    private MissionService missionService;

    @GetMapping("/api/users/{user-id}/missions/{mission-id}")
    public FullMissionDTO getMission(Authentication auth,
                                     @PathVariable("user-id") Long userId,
                                     @PathVariable("mission-id") Long missionId)
            throws MissionException, SoldierException {
        return missionService.getMission(auth.getName(), userId, missionId);
    }

    @PostMapping("/api/users/{user-id}/missions")
    public FullMissionDTO createMission(Authentication auth,
                                        @PathVariable("user-id") Long userId,
                                        @Valid @RequestBody MissionRequest newMission)
            throws SoldierException {
        return missionService.createMission(auth.getName(), userId, newMission);
    }

    @PatchMapping("/api/users/{user-id}/missions/{mission-id}")
    public FullMissionDTO updateMission(Authentication auth,
                                        @PathVariable("user-id") Long userId,
                                        @PathVariable("mission-id") Long missionId,
                                        @Valid @RequestBody MissionRequest updatedMission)
            throws MissionException, SoldierException {
        return missionService.updateMission(auth.getName(), userId, missionId, updatedMission);
    }

    @PatchMapping("/api/users/{user-id}/missions/{mission-id}/complexity/{complexity}")
    public FullMissionDTO updateMissionComplexity(Authentication auth,
                                                  @PathVariable("user-id") Long userId,
                                                  @PathVariable("mission-id") Long missionId,
                                                  @PathVariable("complexity") double complexity)
            throws MissionException, SoldierException {
        return missionService.updateMissionComplexity(auth.getName(), userId, missionId, complexity);
    }

    @GetMapping("/api/users/{user-id}/missions")
    public List<MissionDTO> getMissions(Authentication auth,
                                        @PathVariable("user-id") Long userId)
            throws SoldierException {
        return missionService.getMissions(auth.getName(), userId);
    }
}
