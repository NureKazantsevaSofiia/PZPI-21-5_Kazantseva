package com.ualogistics.main_service.util.swagger;

import com.ualogistics.main_service.model.response.LoginResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

@Tag(name = "Auth API", description = "The API provides user authentication through login")
public interface AuthAPI {

    @Operation(summary = "Login",
            description = "Authenticates the user and returns their ID, token, first name, last name, and role.",
            parameters = {
                    @Parameter(
                            name = "Authorization",
                            description = "Basic Auth",
                            in = ParameterIn.HEADER,
                            required = true,
                            schema = @Schema(type = "string")
                    )
            }
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",
                    description = "Successful authentication",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = LoginResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid credentials or missing data", content = @Content),
            @ApiResponse(responseCode = "404", description = "User is not found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)
    })
    @PostMapping("/api/login")
    @ResponseStatus(HttpStatus.OK)
    LoginResponse login(Authentication authentication) throws Exception;
}
