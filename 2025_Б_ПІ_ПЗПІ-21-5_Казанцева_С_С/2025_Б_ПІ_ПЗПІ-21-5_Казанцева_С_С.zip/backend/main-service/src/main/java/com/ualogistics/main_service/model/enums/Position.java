package com.ualogistics.main_service.model.enums;

public enum Position {
    // Солдати та сержанти
//    INFANTRYMAN,        // Піхотинець
//    SNIPER,             // Снайпер
//    MACHINE_GUNNER,     // Кулеметник
//    MEDIC,              // Медик
//    ENGINEER,           // Інженер
//    DRONE_OPERATOR,     // Оператор БПЛА
//    RADIO_OPERATOR,     // Радіотелеграфіст
//    TANK_CREW,          // Танкіст
//    ARTILLERY_GUNNER,   // Артилерист
//    MORTAR_OPERATOR,    // Мінометник

    // Активні
    PLATOON_COMMANDER,  // Командир взводу
    COMPANY_COMMANDER,  // Командир роти 
    BATTALION_COMMANDER, // Командир батальйону
    BRIGADE_COMMANDER,   // Командир бригади
}
