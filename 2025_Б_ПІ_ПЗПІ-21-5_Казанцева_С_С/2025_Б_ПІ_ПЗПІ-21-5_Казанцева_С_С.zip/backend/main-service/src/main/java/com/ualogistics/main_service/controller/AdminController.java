package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.exception.AuthException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.UpdateAdminRequest;
import com.ualogistics.main_service.model.response.AdminDTO;
import com.ualogistics.main_service.model.response.SoldierDTO;
import com.ualogistics.main_service.service.AdminService;
import com.ualogistics.main_service.util.swagger.AdminAPI;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class AdminController implements AdminAPI {

    private final AdminService adminService;

    @GetMapping("/api/admins/{admin-id}")
    public AdminDTO getAdmin(Authentication auth,
                             @PathVariable("admin-id") Long adminId) throws UserException {
        return adminService.getAdmin(auth.getName(), adminId);
    }

    @PatchMapping("/api/admins/{admin-id}")
    public void updateAdmin(Authentication auth,
                            @PathVariable("admin-id") Long adminId,
                            @Valid @RequestBody UpdateAdminRequest updatedAdmin) throws UserException {
        adminService.updateAdmin(auth.getName(), adminId, updatedAdmin);
    }

    @PostMapping("/api/admins/{admin-id}/add/{email}")
    public void addAdmin(Authentication auth,
                         @PathVariable("admin-id") Long adminId,
                         @PathVariable("email") String email)
            throws UserException, SecurityException, AuthException {
        adminService.addAdmin(auth.getName(), adminId, email);
    }

    @PostMapping("/api/admins/{admin-id}/approve/{new-admin-id}")
    public String approveAdmin(Authentication auth,
                               @PathVariable("admin-id") Long adminId,
                               @PathVariable("new-admin-id") Long newAdminId) throws UserException {
        return adminService.approveAdmin(auth.getName(), adminId, newAdminId);
    }

    @PostMapping("/api/admins/{admin-id}/decline/{new-admin-id}")
    public void declineAdmin(Authentication auth,
                             @PathVariable("admin-id") Long adminId,
                             @PathVariable("new-admin-id") Long newAdminId) throws UserException {
        adminService.declineAdmin(auth.getName(), adminId, newAdminId);
    }

    @GetMapping("/api/admins/approved")
    public List<AdminDTO> getApprovedAdmins(Authentication auth) throws UserException {
        return adminService.getApprovedAdmins(auth.getName());
    }

    @GetMapping("/api/admins/not-approved")
    public List<AdminDTO> getNotApprovedAdmins(Authentication auth) throws UserException {
        return adminService.getNotApprovedAdmins(auth.getName());
    }

    @GetMapping("/api/admins/{admin-id}/users")
    public List<SoldierDTO> getUsers(Authentication auth,
                                     @PathVariable("admin-id") Long adminId) throws UserException {
        return adminService.getUsers(auth.getName(), adminId);
    }
}