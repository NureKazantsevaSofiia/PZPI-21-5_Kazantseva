package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.exception.ResourceException;
import com.ualogistics.main_service.exception.UnitException;
import com.ualogistics.main_service.exception.UserException;
import com.ualogistics.main_service.model.request.LogisticianCreateRequest;
import com.ualogistics.main_service.model.request.UnitResourcesRequest;
import com.ualogistics.main_service.service.LogisticianService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
public class LogisticianController {

    private LogisticianService logisticianService;

    @PostMapping("/api/admin/{admin-id}/logisticians")
    public void createNewLogistician(Authentication auth,
                                     @PathVariable("admin-id") Long userId,
                                     @Valid @RequestBody LogisticianCreateRequest newLogistician)
            throws UserException {
        logisticianService.createNewLogistician(auth.getName(), userId, newLogistician);
    }

    @PostMapping("/api/logisticians/{log-id}/units/{unit-id}")
    public void setUpResourcesForUnit(Authentication auth,
                                      @PathVariable("log-id") Long logId,
                                      @PathVariable("unit-id") Long unitId,
                                      @Valid @RequestBody UnitResourcesRequest resources)
            throws UnitException, ResourceException, UserException {
        logisticianService.setUpResourcesForUnit(auth.getName(), logId, unitId, resources);
    }
}
