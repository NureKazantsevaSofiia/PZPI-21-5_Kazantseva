package com.ualogistics.main_service.service;

import com.ualogistics.main_service.exception.MissionException;
import com.ualogistics.main_service.exception.SoldierException;
import com.ualogistics.main_service.model.request.MissionRequest;
import com.ualogistics.main_service.model.response.FullMissionDTO;
import com.ualogistics.main_service.model.response.MissionDTO;

import java.util.List;

public interface MissionService {

    FullMissionDTO getMission(String email, Long userId, Long missionId) throws SoldierException, MissionException;

    FullMissionDTO createMission(String email, Long userId, MissionRequest newMission) throws SoldierException;

    FullMissionDTO updateMission(String email, Long userId, Long missionId, MissionRequest updatedMission)
            throws SoldierException, MissionException;

    List<MissionDTO> getMissions(String email, Long userId) throws SoldierException;

    FullMissionDTO updateMissionComplexity(String email, Long userId, Long missionId, double complexity)
            throws SoldierException, MissionException;
}
