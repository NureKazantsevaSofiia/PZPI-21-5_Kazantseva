package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.model.request.LogisticianCreateRequest;
import com.ualogistics.main_service.model.request.UnitResourcesRequest;
import com.ualogistics.main_service.service.LogisticianService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class LogisticianControllerTest {

    private MockMvc mockMvc;

    @Mock
    private LogisticianService logisticianService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private LogisticianController logisticianController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(logisticianController).build();
        when(authentication.getName()).thenReturn("admin@example.com");
    }

    @Test
    public void testCreateNewLogistician() throws Exception {
        doNothing().when(logisticianService)
                .createNewLogistician(eq("admin@example.com"), eq(1L), any(LogisticianCreateRequest.class));

        mockMvc.perform(post("/api/admin/1/logisticians")
                        .principal(authentication)
                        .contentType(APPLICATION_JSON)
                        .content("""
                                {
                                    "firstName": "Anna",
                                    "lastName": "Smith",
                                    "email": "anna.smith@example.com",
                                    "password": "secure123"
                                }
                                """))
                .andExpect(status().isOk());
    }

    @Test
    public void testSetUpResourcesForUnit() throws Exception {
        doNothing().when(logisticianService)
                .setUpResourcesForUnit(eq("admin@example.com"), eq(2L), eq(10L), any(UnitResourcesRequest.class));

        mockMvc.perform(post("/api/logisticians/2/units/10")
                        .principal(authentication)
                        .contentType(APPLICATION_JSON)
                        .content("""
                                {
                                    "resources": [
                                        {
                                            "resourceId": "res001",
                                            "quantity": 20
                                        },
                                        {
                                            "resourceId": "res002",
                                            "quantity": 50
                                        }
                                    ]
                                }
                                """))
                .andExpect(status().isOk());
    }
}