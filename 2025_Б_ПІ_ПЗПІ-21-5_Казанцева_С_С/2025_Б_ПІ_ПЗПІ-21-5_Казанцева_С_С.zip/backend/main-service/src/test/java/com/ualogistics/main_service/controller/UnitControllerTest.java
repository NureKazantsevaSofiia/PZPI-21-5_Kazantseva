package com.ualogistics.main_service.controller;


import com.ualogistics.main_service.model.request.UnitCreateRequest;
import com.ualogistics.main_service.model.request.UnitUpdateRequest;
import com.ualogistics.main_service.model.response.UnitDTO;
import com.ualogistics.main_service.service.UnitService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class UnitControllerTest {

    private MockMvc mockMvc;

    @Mock
    private UnitService unitService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private UnitController unitController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(unitController).build();
        when(authentication.getName()).thenReturn("admin@example.com");
    }

    @Test
    public void testGetUnitTypes() throws Exception {
        when(unitService.getUnitTypes("admin@example.com", 1L)).thenReturn(List.of("Type1", "Type2"));

        mockMvc.perform(get("/api/users/1/units/types").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    @Test
    public void testGetUnitByUser() throws Exception {
        UnitDTO dto = UnitDTO.builder().id(1L).name("Unit1").type("Type1").build();
        when(unitService.getUnitByUser("admin@example.com", 1L)).thenReturn(dto);

        mockMvc.perform(get("/api/users/1/unit").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Unit1")));
    }

    @Test
    public void testGetUnit() throws Exception {
        UnitDTO dto = UnitDTO.builder().id(2L).name("Unit2").type("Type2").build();
        when(unitService.getUnit("admin@example.com", 1L, 2L)).thenReturn(dto);

        mockMvc.perform(get("/api/users/1/units/2").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Unit2")));
    }

    @Test
    public void testCreateUnit() throws Exception {
        UnitDTO dto = UnitDTO.builder().id(3L).name("New Unit").type("Support").build();
        when(unitService.createUnit(eq("admin@example.com"), eq(1L), any(UnitCreateRequest.class))).thenReturn(dto);

        mockMvc.perform(post("/api/users/1/units")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                {
                                    "name": "New Unit",
                                    "type": "Support",
                                    "soldierAmount": 20
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("New Unit")));
    }

    @Test
    public void testUpdateUnit() throws Exception {
        UnitDTO dto = UnitDTO.builder().id(4L).name("Updated Unit").type("Command").build();
        when(unitService.updateUnit(eq("admin@example.com"), eq(1L), eq(4L), any(UnitUpdateRequest.class))).thenReturn(dto);

        mockMvc.perform(patch("/api/users/1/units/4")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                {
                                    "name": "Updated Unit"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Updated Unit")));
    }
}