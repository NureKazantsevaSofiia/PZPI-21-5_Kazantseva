package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.model.request.ResourceNewRequest;
import com.ualogistics.main_service.model.response.ResourceResponse;
import com.ualogistics.main_service.service.ResourceService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class ResourceControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ResourceService resourceService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private ResourceController resourceController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(resourceController).build();
        when(authentication.getName()).thenReturn("admin@example.com");
    }

    @Test
    public void testAddResource() throws Exception {
        ResourceResponse response = new ResourceResponse();
        response.setId("res123");
        response.setName("Ration Pack");
        response.setCategory("Food");
        response.setPrice(new BigDecimal("10.50"));

        when(resourceService.addResource(eq("admin@example.com"), eq(1L), any(ResourceNewRequest.class)))
                .thenReturn(response);

        mockMvc.perform(post("/api/admins/1/resources")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                {
                                    "name": "Ration Pack",
                                    "category": "Food",
                                    "price": 10.50
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Ration Pack")))
                .andExpect(jsonPath("$.category", is("Food")))
                .andExpect(jsonPath("$.price", is(10.50)));
    }

    @Test
    public void testUpdateResource() throws Exception {
        ResourceResponse response = new ResourceResponse();
        response.setId("res123");
        response.setName("Updated Pack");
        response.setCategory("Supplies");
        response.setPrice(new BigDecimal("15.75"));

        when(resourceService.updateResource(eq("admin@example.com"), eq(1L), eq("res123"), any(ResourceNewRequest.class)))
                .thenReturn(response);

        mockMvc.perform(patch("/api/admins/1/resources/res123")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                {
                                    "name": "Updated Pack",
                                    "category": "Supplies",
                                    "price": 15.75
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Updated Pack")))
                .andExpect(jsonPath("$.price", is(15.75)));
    }

    @Test
    public void testGetResource() throws Exception {
        ResourceResponse response = new ResourceResponse();
        response.setId("res123");
        response.setName("Tent");
        response.setCategory("Shelter");
        response.setPrice(new BigDecimal("50.00"));

        when(resourceService.getResource("admin@example.com", 2L, "res123")).thenReturn(response);

        mockMvc.perform(get("/api/users/2/resources/res123").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Tent")))
                .andExpect(jsonPath("$.category", is("Shelter")));
    }

    @Test
    public void testGetAllResources() throws Exception {
        ResourceResponse res1 = new ResourceResponse();
        res1.setName("Water Bottle");
        ResourceResponse res2 = new ResourceResponse();
        res2.setName("First Aid Kit");

        when(resourceService.getAllResources("admin@example.com", 2L)).thenReturn(List.of(res1, res2));

        mockMvc.perform(get("/api/users/2/resources-list").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].name", is("Water Bottle")))
                .andExpect(jsonPath("$[1].name", is("First Aid Kit")));
    }

    @Test
    public void testSearchResourcesByName() throws Exception {
        ResourceResponse res = new ResourceResponse();
        res.setName("Field Radio");

        when(resourceService.searchResourcesByName("admin@example.com", 2L, "radio"))
                .thenReturn(List.of(res));

        mockMvc.perform(get("/api/users/2/resources/search/radio").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].name", is("Field Radio")));
    }
}

