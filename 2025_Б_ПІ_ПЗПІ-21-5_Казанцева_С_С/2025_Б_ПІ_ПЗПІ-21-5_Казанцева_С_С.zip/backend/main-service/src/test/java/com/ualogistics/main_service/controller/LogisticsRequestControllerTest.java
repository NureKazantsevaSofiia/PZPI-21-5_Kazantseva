package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.model.response.LogisticsRequestDTO;
import com.ualogistics.main_service.service.LogisticsRequestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class LogisticsRequestControllerTest {

    private MockMvc mockMvc;

    @Mock
    private LogisticsRequestService logisticsRequestService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private LogisticsRequestController logisticsRequestController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(logisticsRequestController).build();
        when(authentication.getName()).thenReturn("admin@example.com");
    }

    @Test
    public void testGetRequestStatuses() throws Exception {
        when(logisticsRequestService.getRequestStatuses(eq("admin@example.com"), eq(2L)))
                .thenReturn(List.of("PENDING", "APPROVED"));

        mockMvc.perform(get("/api/users/2/request-statuses").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0]", is("PENDING")));
    }

    @Test
    public void testCreateLogisticsRequest() throws Exception {
        LogisticsRequestDTO dto = LogisticsRequestDTO.builder()
                .id(1L).status("PENDING").missionId(3L).build();

        when(logisticsRequestService.createLogisticsRequest(eq("admin@example.com"), eq(2L), eq(3L), any()))
                .thenReturn(dto);

        mockMvc.perform(post("/api/users/2/missions/3/requests")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                {
                                    "status": "PENDING",
                                    "resources": [
                                        {"resourceId": "res-123", "quantity": 5},
                                        {"resourceId": "res-456", "quantity": 10}
                                    ]
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status", is("PENDING")));
    }

    @Test
    public void testUpdateLogisticsRequestStatus() throws Exception {
        LogisticsRequestDTO dto = LogisticsRequestDTO.builder()
                .id(5L).status("APPROVED").build();

        when(logisticsRequestService.updateStatusLogisticsRequest(eq("admin@example.com"), eq(2L), eq(3L), eq(5L), eq("APPROVED")))
                .thenReturn(dto);

        mockMvc.perform(patch("/api/users/2/missions/3/requests/5/status/APPROVED")
                        .principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status", is("APPROVED")));
    }

    @Test
    public void testUpdateLogisticsRequest() throws Exception {
        LogisticsRequestDTO dto = LogisticsRequestDTO.builder()
                .id(5L).status("UPDATED").build();

        when(logisticsRequestService.updateLogisticsRequest(eq("admin@example.com"), eq(2L), eq(3L), eq(5L), any()))
                .thenReturn(dto);

        mockMvc.perform(patch("/api/users/2/missions/3/requests/5")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                {
                                    "status": "UPDATED",
                                    "resources": [
                                        {"resourceId": "res-999", "quantity": 20}
                                    ]
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status", is("UPDATED")));
    }

    @Test
    public void testGetLogisticsRequestsByUnit() throws Exception {
        LogisticsRequestDTO dto = LogisticsRequestDTO.builder().id(1L).status("PENDING").build();
        when(logisticsRequestService.getLogisticsRequestsByUnit(eq("admin@example.com"), eq(2L), eq(6L)))
                .thenReturn(List.of(dto));

        mockMvc.perform(get("/api/users/2/units/6/requests").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].status", is("PENDING")));
    }
}

