package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.model.request.MissionRequest;
import com.ualogistics.main_service.model.response.FullMissionDTO;
import com.ualogistics.main_service.model.response.MissionDTO;
import com.ualogistics.main_service.service.MissionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class MissionControllerTest {

    private MockMvc mockMvc;

    @Mock
    private MissionService missionService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private MissionController missionController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(missionController).build();
        when(authentication.getName()).thenReturn("admin@example.com");
    }

    @Test
    public void testGetMission() throws Exception {
        FullMissionDTO dto = FullMissionDTO.builder()
                .id(1L)
                .description("Secure the area")
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now().plusHours(2))
                .requests(List.of())
                .build();

        when(missionService.getMission("admin@example.com", 1L, 1L)).thenReturn(dto);

        mockMvc.perform(get("/api/users/1/missions/1").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.description", is("Secure the area")));
    }

    @Test
    public void testCreateMission() throws Exception {
        FullMissionDTO dto = FullMissionDTO.builder()
                .id(1L)
                .description("Secure the area")
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now().plusHours(2))
                .requests(List.of())
                .build();

        when(missionService.createMission(eq("admin@example.com"), eq(1L), any(MissionRequest.class))).thenReturn(dto);

        mockMvc.perform(post("/api/users/1/missions")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                    {
                                        "description": "Secure the area",
                                        "startTime": "2025-06-09T17:13:15.870234",
                                        "endTime": "2025-06-09T19:13:15.870234"
                                    }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.description", is("Secure the area")));
    }

    @Test
    public void testUpdateMission() throws Exception {
        FullMissionDTO dto = FullMissionDTO.builder()
                .id(1L)
                .description("Updated mission")
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now().plusHours(2))
                .requests(List.of())
                .build();

        when(missionService.updateMission(eq("admin@example.com"), eq(1L), eq(1L), any(MissionRequest.class))).thenReturn(dto);

        mockMvc.perform(patch("/api/users/1/missions/1")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                    {
                                        "description": "Updated mission",
                                        "startTime": "2025-06-09T17:13:15.870234",
                                        "endTime": "2025-06-09T19:13:15.870234"
                                    }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.description", is("Updated mission")));
    }

    @Test
    public void testUpdateMissionComplexity() throws Exception {
        FullMissionDTO dto = FullMissionDTO.builder()
                .id(1L)
                .description("Complex mission")
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now().plusHours(2))
                .requests(List.of())
                .build();

        when(missionService.updateMissionComplexity("admin@example.com", 1L, 1L, 3.5)).thenReturn(dto);

        mockMvc.perform(patch("/api/users/1/missions/1/complexity/3.5").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.description", is("Complex mission")));
    }

    @Test
    public void testGetMissions() throws Exception {
        MissionDTO dto = MissionDTO.builder()
                .id(1L)
                .description("Patrol mission")
                .complexity(5.0)
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now().plusHours(2))
                .build();

        when(missionService.getMissions("admin@example.com", 1L)).thenReturn(List.of(dto));

        mockMvc.perform(get("/api/users/1/missions").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].description", is("Patrol mission")));
    }
}
