package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.model.request.SoldierRequest;
import com.ualogistics.main_service.model.response.SoldierDTO;
import com.ualogistics.main_service.service.SoldierService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class SoldierControllerTest {

    private MockMvc mockMvc;

    @Mock
    private SoldierService soldierService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private SoldierController soldierController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(soldierController).build();
        when(authentication.getName()).thenReturn("admin@example.com");
    }

    @Test
    public void testGetPositions() throws Exception {
        when(soldierService.getPositions("admin@example.com", 1L))
                .thenReturn(List.of("Commander", "Medic"));

        mockMvc.perform(get("/api/users/1/positions").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    @Test
    public void testGetSoldier() throws Exception {
        SoldierDTO dto = SoldierDTO.builder()
                .firstName("John")
                .lastName("Doe")
                .email("john@example.com")
                .position("Commander")
                .unit("Unit1")
                .build();

        when(soldierService.getSoldier("admin@example.com", 1L)).thenReturn(dto);

        mockMvc.perform(get("/api/users/1").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName", is("John")));
    }

    @Test
    public void testUpdateSoldier() throws Exception {
        SoldierDTO dto = SoldierDTO.builder().firstName("Updated").build();
        when(soldierService.updateSoldier(eq("admin@example.com"), eq(1L), any(SoldierRequest.class))).thenReturn(dto);

        mockMvc.perform(patch("/api/users/1")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                    {
                                        "firstName": "Updated",
                                        "lastName": "Doe",
                                        "personalNumber": "123456",
                                        "password": "secure123"
                                    }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName", is("Updated")));
    }

    @Test
    public void testCreateNewSoldier() throws Exception {
        doNothing().when(soldierService).createNewSoldier(eq("admin@example.com"), eq(1L), any());

        mockMvc.perform(post("/api/users/1/soldiers")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                    {
                                        "firstName": "New",
                                        "lastName": "Soldier",
                                        "email": "new@soldier.com",
                                        "password": "pass1234",
                                        "position": "Private",
                                        "personalNumber": "PN123"
                                    }
                                """))
                .andExpect(status().isOk());
    }

    @Test
    public void testCreateBrigadeCommander() throws Exception {
        doNothing().when(soldierService).createBrigadeCommander(eq("admin@example.com"), eq(1L), any());

        mockMvc.perform(post("/api/admins/1/soldiers")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                    {
                                        "firstName": "Commander",
                                        "lastName": "Leader",
                                        "email": "commander@army.com",
                                        "password": "cmd12345",
                                        "position": "Brigade Commander",
                                        "personalNumber": "CMD001"
                                    }
                                """))
                .andExpect(status().isOk());
    }
}
