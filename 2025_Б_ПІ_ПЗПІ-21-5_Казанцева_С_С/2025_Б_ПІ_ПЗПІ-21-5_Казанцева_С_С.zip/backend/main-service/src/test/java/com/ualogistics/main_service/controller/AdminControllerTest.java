package com.ualogistics.main_service.controller;

import com.ualogistics.main_service.model.response.AdminDTO;
import com.ualogistics.main_service.service.AdminService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class AdminControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AdminService adminService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private AdminController adminController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(adminController).build();
        when(authentication.getName()).thenReturn("admin@example.com");
    }

    @Test
    public void testGetAdmin() throws Exception {
        AdminDTO mockAdmin = new AdminDTO();
        when(adminService.getAdmin("admin@example.com", 1L)).thenReturn(mockAdmin);

        mockMvc.perform(get("/api/admins/1").principal(authentication))
                .andExpect(status().isOk());
    }

    @Test
    public void testUpdateAdmin() throws Exception {
        doNothing().when(adminService).updateAdmin(eq("admin@example.com"), eq(1L), any());

        mockMvc.perform(patch("/api/admins/1")
                        .principal(authentication)
                        .contentType("application/json")
                        .content("""
                                    {
                                        "firstName": "John",
                                        "lastName": "Doe",
                                        "password": "Secure1234"
                                    }
                                """))
                .andExpect(status().isOk());
    }

    @Test
    public void testAddAdmin() throws Exception {
        doNothing().when(adminService).addAdmin("admin@example.com", 1L, "newadmin@example.com");

        mockMvc.perform(post("/api/admins/1/add/newadmin@example.com").principal(authentication))
                .andExpect(status().isOk());
    }

    @Test
    public void testApproveAdmin() throws Exception {
        when(adminService.approveAdmin("admin@example.com", 1L, 2L)).thenReturn("Approved");

        mockMvc.perform(post("/api/admins/1/approve/2").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(content().string("Approved"));
    }

    @Test
    public void testDeclineAdmin() throws Exception {
        doNothing().when(adminService).declineAdmin("admin@example.com", 1L, 2L);

        mockMvc.perform(post("/api/admins/1/decline/2").principal(authentication))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetApprovedAdmins() throws Exception {
        when(adminService.getApprovedAdmins("admin@example.com")).thenReturn(List.of(new AdminDTO()));

        mockMvc.perform(get("/api/admins/approved").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)));
    }

    @Test
    public void testGetNotApprovedAdmins() throws Exception {
        when(adminService.getNotApprovedAdmins("admin@example.com")).thenReturn(List.of(new AdminDTO()));

        mockMvc.perform(get("/api/admins/not-approved").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)));
    }

    @Test
    public void testGetUsers() throws Exception {
        when(adminService.getUsers("admin@example.com", 1L)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/admins/1/users").principal(authentication))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));
    }
}
