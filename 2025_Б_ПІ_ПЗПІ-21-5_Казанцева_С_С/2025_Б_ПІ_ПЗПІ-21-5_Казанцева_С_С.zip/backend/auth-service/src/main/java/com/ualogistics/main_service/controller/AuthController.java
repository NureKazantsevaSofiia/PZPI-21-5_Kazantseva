package com.ualogistics.main_service.controller;

import com.nimbusds.jose.JOSEException;
import com.ualogistics.auth_common.service.JweService;
import com.ualogistics.main_service.model.entity.TokenBlacklist;
import com.ualogistics.main_service.model.request.TokenRequest;
import com.ualogistics.main_service.model.response.TokenResponse;
import com.ualogistics.main_service.repository.TokenBlacklistRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;

@RestController
@RequestMapping("/api")
@AllArgsConstructor
public class AuthController {

    private final JweService jweService;
    private final TokenBlacklistRepository tokenBlacklistRepository;

    @PostMapping("/login")
    public ResponseEntity<TokenResponse> login(Authentication authentication) throws JOSEException {
        String email = authentication.getName();
        String token = jweService.generateEncryptedToken(email);
        long expiresIn = 3600;
        return ResponseEntity.ok(new TokenResponse(token, expiresIn));
    }

    @PostMapping("/validate")
    public ResponseEntity<Boolean> validate(@RequestBody TokenRequest tokenRequest) {
        try {
            String email = jweService.extractSubject(tokenRequest.getToken());
            return ResponseEntity.ok(email != null);
        } catch (Exception e) {
            return ResponseEntity.ok(false);
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<Boolean> logout(@RequestHeader("Authorization") String header) {
        String token = header.replace("Bearer ", "");
        tokenBlacklistRepository.save(new TokenBlacklist(token, Instant.now()));
        return ResponseEntity.ok(true);
    }
}
