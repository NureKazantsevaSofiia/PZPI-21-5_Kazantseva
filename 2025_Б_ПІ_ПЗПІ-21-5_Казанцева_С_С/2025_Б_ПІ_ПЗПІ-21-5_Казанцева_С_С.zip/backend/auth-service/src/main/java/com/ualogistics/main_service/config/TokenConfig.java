package com.ualogistics.main_service.config;

import com.ualogistics.auth_common.service.JweService;
import com.ualogistics.main_service.repository.TokenBlacklistRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;

@Configuration
public class TokenConfig {

    private final TokenBlacklistRepository blacklistRepository;

    public TokenConfig(TokenBlacklistRepository blacklistRepository) {
        this.blacklistRepository = blacklistRepository;
    }

    @Bean
    public KeyPair keyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        return generator.generateKeyPair();
    }

    @Bean
    public JweService jweService(KeyPair keyPair) {
        return new JweService(keyPair);
    }

    @Bean
    public JweJwtDecoder jweJwtDecoder(JweService jweService) {
        return new JweJwtDecoder(jweService, blacklistRepository);
    }
}
