package com.ualogistics.main_service.model.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class TokenBlacklist {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    private String token;

    private Instant revokedAt;

    public TokenBlacklist(String token, Instant revokedAt) {
        this.token = token;
        this.revokedAt = revokedAt;
    }
}
