package com.ualogistics.main_service.config;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.ualogistics.auth_common.service.JweService;
import com.ualogistics.main_service.repository.TokenBlacklistRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
@AllArgsConstructor
public class JweJwtDecoder implements JwtDecoder {

    private final JweService jweService;
    private final TokenBlacklistRepository blacklistRepository;

    @Override
    public Jwt decode(String token) throws JwtException {
        try {
            EncryptedJWT jwt = EncryptedJWT.parse(token);
            jwt.decrypt(new RSADecrypter(jweService.getPrivateKey()));

            JWTClaimsSet claimsSet = jwt.getJWTClaimsSet();

            Date expiration = claimsSet.getExpirationTime();
            if (expiration == null || expiration.before(new Date())) {
                throw new JwtException("Token has expired");
            }

            if (blacklistRepository.existsByToken(token)) {
                throw new JwtException("Token has been revoked");
            }

            Map<String, Object> headers = Map.of("alg", "RSA_OAEP_256", "enc", "A256GCM");

            Map<String, Object> claims = new HashMap<>();
            claims.put("sub", claimsSet.getSubject());
            claims.put("exp", expiration);

            return new Jwt(token, claimsSet.getIssueTime().toInstant(), expiration.toInstant(), headers, claims);
        } catch (ParseException | JOSEException e) {
            throw new JwtException("Invalid JWT: " + e.getMessage());
        }
    }
}
