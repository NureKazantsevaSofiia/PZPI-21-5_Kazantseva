package com.ualogistics.main_service.model.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TokenRequest {

    private String token;

}
