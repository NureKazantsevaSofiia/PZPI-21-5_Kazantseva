INSERT INTO users (email, password, role)
VALUES ('admin@ualogistics.com',
        '$2a$10$4v91StFnS3jHcEvKAw9r7OyDhmxkHrbwZK3svxH7n.T1qv7hkJ64O', -- password: admin123
        'ADMIN');